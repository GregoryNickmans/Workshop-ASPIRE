(() => {
  "use strict";
  const slides = window.workshopSlides;
  if (!slides?.length) return;
  const $ = id => document.getElementById(id);
  const dialog = $("toc-dialog");
  const escape = text => String(text).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  let current = 0;
  function render() {
    const requested = location.hash.slice(1) || slides[0].id;
    const canonical = window.workshopHashAliases?.[requested] || requested;
    const found = slides.findIndex(slide => slide.id === canonical);
    current = found < 0 ? 0 : found;
    const slide = slides[current];
    $("slide").dataset.view = slide.view || "content";
    $("slide-meta").hidden = false;
    $("slide-content").hidden = slide.view === "divider";
    const outcome = slide.outcome ?? "";
    $("slide-outcome").hidden = !outcome.trim() || ["divider", "growth", "architecture"].includes(slide.view) || slide.id === "agenda";
    $("slide-title").textContent = slide.title;
    $("slide-meta").textContent = slide.meta;
    $("slide-content").innerHTML = slide.html;
    $("slide-outcome").textContent = outcome;
    $("slide-counter").textContent = `${current + 1} / ${slides.length}`;
    $("previous-button").disabled = current === 0;
    $("next-button").disabled = current === slides.length - 1;
    document.title = `ASPIRE Workshop · ${slide.title}`;
    $("slide").scrollTop = 0;
    $("slide-content").scrollTop = 0;
    $("slide-content").querySelectorAll(".diagram-scroll").forEach(element => { element.scrollLeft = 0; });
    window.scrollTo(0, 0);
    // A PROMPT slide hands its plain text to the clipboard; nothing is fetched or generated.
    const copyButton = $("slide-content").querySelector("[data-prompt-copy]");
    if (copyButton) {
      copyButton.addEventListener("click", async () => {
        const prompt = $("slide-content").querySelector(".prompt-text");
        const text = prompt?.textContent ?? "";
        try {
          if (!navigator.clipboard?.writeText) throw new Error("Clipboard unavailable");
          await navigator.clipboard.writeText(text);
          copyButton.textContent = "Copied";
        } catch {
          // file:// and denied permissions fall back to selecting the text for a manual copy.
          const selection = window.getSelection();
          const range = document.createRange();
          range.selectNodeContents(prompt);
          selection.removeAllRanges();
          selection.addRange(range);
          copyButton.textContent = "Selected — press Ctrl+C";
        }
      });
    }
  }
  function go(index) { location.hash = slides[Math.max(0, Math.min(slides.length - 1, index))].id; }
  $("previous-button").addEventListener("click", () => go(current - 1));
  $("next-button").addEventListener("click", () => go(current + 1));
  $("toc-links").innerHTML = slides.filter(slide => slide.toc).map(slide => `<a href="#${escape(slide.id)}">${escape(slide.chapter)} · ${escape(slide.title)}</a>`).join("");
  $("toc-button").addEventListener("click", () => { if (typeof dialog.showModal === "function") dialog.showModal(); else { dialog.setAttribute("open", ""); $("toc-close").focus(); } });
  const closeToc = () => { if (typeof dialog.close === "function") dialog.close(); else dialog.removeAttribute("open"); };
  $("toc-close").addEventListener("click", closeToc);
  $("toc-links").addEventListener("click", event => { if (event.target.closest("a")) closeToc(); });
  document.addEventListener("keydown", event => {
    if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey || dialog.open) return;
    if (event.target.closest("input, textarea, select, button, [contenteditable], [role='dialog']")) return;
    const routes = {ArrowLeft:()=>go(current-1),ArrowRight:()=>go(current+1),Home:()=>go(0),End:()=>go(slides.length-1)};
    if (routes[event.key]) { event.preventDefault(); routes[event.key](); }
  });
  window.addEventListener("hashchange", render);
  render();
})();
