/* Offline architecture roadmap and focused code from the implemented local milestones. */
(() => {
  "use strict";
  const escape = text => String(text).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  const p = text => `<p>${text}</p>`;
  const list = items => `<ul>${items.map(item => `<li>${item}</li>`).join("")}</ul>`;
  const code = (text, highlights = []) => {
    // Match original code only; prefer longer literals and never re-match generated markup.
    const targets = [...new Set(highlights)].filter(target => target.length > 0).sort((a, b) => b.length - a.length);
    const pattern = targets.length ? new RegExp(`(${targets.map(target => target.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")})`, "g") : null;
    const markup = pattern
      ? String(text).split(pattern).map((part, index) => index % 2 ? `<mark class="code-highlight">${escape(part)}</mark>` : escape(part)).join("")
      : escape(text);
    return `<pre><code>${markup}</code></pre>`;
  };
  const columns = (left, right) => `<div class="columns"><div>${left}</div><div>${right}</div></div>`;
  // The seven visible roadmap milestones own the implementation chapter titles and diagrams.
  const milestones = [
    {id:"build-apphost",chapterId:"apphost",title:"Bring the system into ASPIRE",topology:"orchestrated",addition:"apphost",claim:"Add orchestration"},
    {id:"build-sql",chapterId:"sql",title:"Persist application state",topology:"sql",addition:"sql",claim:"Add a SQL database behind the API"},
    {id:"build-migrator",chapterId:"migrator",title:"Migrator",topology:"migrated",addition:"migrator",claim:"Add one-shot Migrator → SQL"},
    {id:"build-seeder",chapterId:"seeding",title:"Apply local seeding",topology:"seeded",addition:"seeder",claim:"Local command: drops the database, apply migrations and then seed some data"},
    {id:"build-blobs",chapterId:"blobs",title:"Blobstorage",topology:"blobs",addition:"blobs",claim:"Add Blob Storage"},
    {id:"build-messaging",chapterId:"servicebus",title:"Asynchronous processing (messaging)",topology:"messaging",addition:"servicebus",claim:"Move PDF generation to a worker; API persists ticket metadata"},
    {id:"build-notifications",chapterId:"signalr",title:"Notify (SignalR)",topology:"notifications",addition:"notifications",claim:"Add Serverless SignalR for business notifications"}
  ];
  const chapters = [
    {id:"why-aspire",title:"ASPIRE fundamentals"},
    {id:"current-catalog",title:"Current application"},
    {id:"blazor-start",title:"What we will build"},
    {id:"setup",title:"Setup the project"},
    ...milestones.flatMap(milestone => [
      ...(milestone.chapterId === "signalr" ? [{id:"observability",title:"Observability"}] : []),
      {id:milestone.chapterId,title:milestone.title}
    ]),
    {id:"testing",title:"Testing"},
    {id:"finish",title:"References"}
  ].map((chapter,index) => ({...chapter,number:index+1}));
  // Absence means absent, never a faded future resource. SQLite is embedded in the baseline API.
  const topologies = {
    baseline: {resources:["frontend","api"],apphost:false,production:false},
    orchestrated: {resources:["frontend","api"],apphost:true,production:false},
    sql: {resources:["frontend","api","sql"],apphost:true,production:false},
    migrated: {resources:["frontend","api","sql","migrator"],apphost:true,production:false},
    seeded: {resources:["frontend","api","sql","migrator","seeder"],apphost:true,production:false},
    blobs: {resources:["frontend","api","sql","migrator","seeder","blobs"],apphost:true,production:false},
    messaging: {resources:["frontend","api","sql","migrator","seeder","blobs","servicebus","processor"],apphost:true,production:false},
    notifications: {resources:["frontend","api","sql","migrator","seeder","blobs","servicebus","processor","notifications"],apphost:true,production:false}
  };
  const icons = {sql:"sql-database.svg",blobs:"storage-account.svg",servicebus:"service-bus.svg",notifications:"signalr.svg"};
  const genericIcon = (kind,x,y) => {
    const shapes = {
      frontend:'<rect x="2" y="4" width="36" height="28" rx="2"/><path d="M2 12 H38 M8 8 H9 M13 8 H14 M10 19 H30 M10 25 H23"/>',
      api:'<path d="M12 8 L3 20 L12 32 M28 8 L37 20 L28 32 M23 5 L17 35"/>',
      migrator:'<path d="M6 8 H34 V34 H6 Z M12 15 H27 M22 10 L28 15 L22 20 M12 27 H28"/>',
      seeder:'<path d="M20 36 V18 M20 24 C4 24 4 8 4 8 C20 8 20 16 20 24 M20 18 C20 3 36 4 36 4 C36 18 28 18 20 18"/>',
      processor:'<rect x="3" y="6" width="28" height="28" rx="2"/><path d="M10 14 H23 M10 21 H23 M25 27 H39 M34 22 L39 27 L34 32"/>'
    };
    return `<g class="workload-icon" transform="translate(${x} ${y})" aria-hidden="true">${shapes[kind]}</g>`;
  };
  let diagramNumber = 0;
  function architecture(snapshotName,focused=null) {
    const snapshot = topologies[snapshotName];
    const has = resource => snapshot.resources.includes(resource);
    const marker = `arrow-${++diagramNumber}`;
    const state = resource => focused===resource || (focused==="servicebus" && resource==="processor") || (focused==="observability" && ["api","processor"].includes(resource)) ? "changed" : "existing";
    const node = (resource,x,y,w,h,title,detail) => {
      const image = icons[resource]
        ? `<image href="assets/azure/${icons[resource]}" x="${x+14}" y="${y+18}" width="40" height="40" preserveAspectRatio="xMidYMid meet"/>`
        : genericIcon(resource,x+14,y+18);
      return `<g class="node ${state(resource)}" data-resource="${resource}"><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="4"/>${image}<text x="${x+66}" y="${y+33}" class="node-title">${escape(title)}</text><text x="${x+16}" y="${y+h-18}" class="node-detail">${escape(detail)}</text></g>`;
    };
    const edge = (resource,path,label,x,y,control=false,from="",to="") => `<g class="edge ${control?"control ":""}${state(resource)}" data-relationship="${resource}"${from?` data-source="${from}" data-target="${to}"`:""}><path d="${path}" marker-end="url(#${marker})"/>${label?`<text x="${x}" y="${y}" text-anchor="middle">${escape(label)}</text>`:""}</g>`;
    const boundary = snapshot.apphost ? `<g class="orchestration ${state("apphost")}" data-resource="apphost"><rect x="28" y="22" width="1360" height="628" rx="8"/><text x="52" y="51" class="boundary-title">AppHost · local orchestration</text><text x="52" y="78">Service Defaults + dashboard · configuration and readiness</text></g>${edge("apphost","M185 90 V145","configure / wait",185,122,true)}${edge("apphost","M600 90 V145","configure / wait",600,122,true)}` : "";
    const description = `Solid arrows carry data; dashed arrows coordinate startup. ${snapshotName==="baseline" || snapshotName==="orchestrated" ? "Courses and bookings already persist in embedded SQLite inside the API. " : "Application SQL is a separate SQL Server resource. "}${has("processor")?"The API commits confirmation, then publishes GenerateTicket; the worker generates private PDFs and publishes TicketGenerated; only the API persists SQL metadata.":""}${has("notifications")?"SignalR publishes best-effort post-commit hints; browsers reload authoritative REST state.":""}${has("seeder")?"Seeder remains local-only; its manual command drops the database, applies migrations and seeds demo data. The API does not wait for Seeder.":""}`;
    return `<figure class="architecture" data-topology="${snapshotName}"><div class="diagram-scroll"><svg viewBox="0 0 1400 680" role="img" aria-label="${escape(description)}"><title>${escape(snapshotName)} application topology</title><desc>${escape(snapshot.resources.join(", "))}${snapshot.apphost?"; AppHost outside business traffic":""}. ${escape(description)}</desc><defs><marker id="${marker}" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto-start-reverse" markerUnits="userSpaceOnUse"><path d="M0 0 L8 4 L0 8 Z" class="arrowhead"/></marker></defs>
      ${boundary}
      ${edge("business","M310 205 H440","HTTP / REST",375,191)}
      ${has("sql")?edge("sql","M760 165 H1050",has("servicebus")?"persist / query":"queries",905,155):""}
      ${has("migrator")?edge("migrator","M760 585 H850 V185 H1050","schema",803,577)+edge("migrator","M600 540 V255","Finished + exit 0",684,515,true):""}
      ${has("seeder")?edge("seeder","M360 585 H395 V638 H810 V200 H1050","drop / migrate / seed",490,632)+edge("seeder","M460 575 H360","exit 0",410,560,true):""}
      ${has("blobs")?edge("blobs","M760 205 H905 V280 H1050","bytes",976,270):""}
      ${has("processor")?edge("processor","M500 435 H1010","TicketGenerated → ticket",755,425,false,"processor","servicebus")+edge("processor","M1010 465 H500","ticket-generator → PDF worker",755,487,false,"servicebus","processor")+edge("blobs","M420 390 V350 H1205 V325","worker creates / reuses PDF blob",810,342,false,"processor","blobs"):""}
      ${has("servicebus")?edge("servicebus","M760 235 H940 V395 H1010","GenerateTicket → ticket",866,224,false,"api","servicebus")+edge("servicebus","M1010 410 H975 V300 H600 V255","ticket-persistence → API",787,291,false,"servicebus","api"):""}
      ${has("notifications")?edge("notifications","M730 255 V330 H990 V575 H1050","optional signal",886,322)+edge("notifications","M1360 595 H1380 V665 H40 V230 H60","browser signal → REST reload",340,675):""}
      ${node("frontend",60,145,250,110,"Blazor frontend","UI + browser client")}
      ${node("api",440,145,320,110,".NET 10 REST API",has("servicebus")?"Submit command · persist completion":"Application endpoint")}
      ${has("sql")?node("sql",1050,120,310,90,"sqlServer","Local SQL Server container"):""}
      ${has("migrator")?node("migrator",460,540,300,85,"migrations","Migrator · one-shot schema gate"):""}
      ${has("seeder")?node("seeder",60,540,300,85,"Local Seeder","Optional · API does not wait"):""}
      ${has("processor")?node("processor",60,390,440,100,"serviceBusProcessor","PDF worker · render / upload"):""}
      ${has("blobs")?node("blobs",1050,240,310,85,"Blob Storage","Azurite · tickets container"):""}
      ${has("servicebus")?node("servicebus",1010,375,350,145,"Azure Service Bus","Emulator · separate SQL backend")+`<text x="1076" y="430" class="node-detail">topic: ticket</text><text x="1026" y="452" class="node-detail">GenerateTicket → ticket-generator</text><text x="1026" y="474" class="node-detail">TicketGenerated → ticket-persistence</text>`:""}
      ${has("notifications")?node("notifications",1050,535,310,85,"Serverless SignalR","Local emulator · post-commit hints"):""}
      </svg></div></figure>`;
  }
  const sources = {
    overview:["What is ASPIRE?","https://aspire.dev/get-started/what-is-aspire/"],
    apphost:["AppHost","https://aspire.dev/get-started/app-host/"],
    discovery:["Service discovery","https://aspire.dev/fundamentals/service-discovery/"],
    health:["Health & readiness","https://aspire.dev/fundamentals/health-checks/"],
    defaults:["Service Defaults","https://aspire.dev/get-started/csharp-service-defaults/"],
    integrations:["Integrations","https://aspire.dev/integrations/overview/"],
    dashboard:["Dashboard","https://aspire.dev/dashboard/overview/"],
    deployment:["Deployment pipelines","https://aspire.dev/deployment/pipelines/"],
    blobHosting:["Blob hosting · 13.6.4","https://github.com/microsoft/aspire/blob/v13.6.4/src/Aspire.Hosting.Azure.Storage/README.md"],
    blobClient:["Blob client · 13.6.4","https://github.com/microsoft/aspire/blob/v13.6.4/src/Components/Aspire.Azure.Storage.Blobs/README.md"],
    busHosting:["Service Bus hosting · 13.6.5","https://github.com/microsoft/aspire/blob/v13.6.5/src/Aspire.Hosting.Azure.ServiceBus/README.md"],
    busApi:["Topic / subscription APIs · 13.6.5","https://github.com/microsoft/aspire/blob/v13.6.5/src/Aspire.Hosting.Azure.ServiceBus/AzureServiceBusExtensions.cs"],
    busClient:["Service Bus client · 13.6.5","https://github.com/microsoft/aspire/blob/v13.6.5/src/Components/Aspire.Azure.Messaging.ServiceBus/README.md"],
    busStart:["Service Bus getting started","https://aspire.dev/integrations/cloud/azure/azure-service-bus/azure-service-bus-get-started/"]
  };
  const concepts = items => `<div class="concepts">${items.map(([title,text])=>`<section><h2>${title}</h2><p>${text}</p></section>`).join("")}</div>`;
  const fundamentals = [
    {id:"why-aspire",title:"What is ASPIRE?",claim:"One code-first model for your application and its dependencies.",visual:concepts([["Orchestrate","Describe resources, configuration and startup relationships."],["Integrate","Connect application clients to the dependencies they use."],["Observe","Inspect resource state and instrumented requests together."]]),detail:"ASPIRE is open-source orchestration and observability for distributed applications. Distributed can mean an application plus a database or another dependency; microservices are optional.",outcome:"Start with the system you have.",sources:["overview"]},
    {id:"aspire-why",title:"Why use it?",claim:"Replace scattered setup with a repeatable application model.",visual:columns('<section class="comparison"><h2>Separate setup</h2>'+list(["Startup commands and port choices","URLs and connection configuration","Logs spread across terminals"])+"</section>",'<section class="comparison"><h2>A shared workflow</h2>'+list(["Named resources in AppHost","References and startup coordination","Dashboard and correlated telemetry"])+"</section>"),detail:"Encode the environment once, then run and diagnose the same resource relationships across your team. You still own meaningful health checks and instrumentation.",outcome:"Less setup drift; a common place to investigate failures.",sources:["overview","apphost"]},
    {id:"aspire-readiness",title:"Wiring is different from readiness",claim:"Receiving configuration does not prove a dependency is usable.",visual:concepts([["WithReference","Supplies connection or discovery configuration."],["WaitFor","Coordinates startup using the resource’s readiness checks."],["WaitForCompletion","Gates startup on successful one-shot completion."]]),detail:"A running process or a self-health endpoint cannot prove that schema exists or a dependency works. Define checks and completion gates that match what the consumer actually needs.",outcome:"Use references for wiring and explicit health/completion gates for readiness.",sources:["discovery","health"]},
    {id:"aspire-model",title:"AppHost models the system",claim:"Resources name the pieces. References describe their relationships.",visual:code('var api = builder.AddProject<Projects.Api>("api");\nbuilder.AddProject<Projects.Frontend>("frontend")\n    .WithReference(api)\n    .WaitFor(api);'),detail:"AppHost is the executable application model. Register processes, containers and supporting resources, then connect them with references and startup dependencies. It stays outside business request traffic.",outcome:"The model coordinates the environment; it does not implement application rules.",sources:["apphost","discovery"]},
    {id:"aspire-defaults",title:"Service Defaults",claim:"Shared operational conventions, customized for your services.",visual:code('builder.AddServiceDefaults();\n\nvar app = builder.Build();\napp.MapDefaultEndpoints();'),detail:"The C# template provides customizable OpenTelemetry, health checks, service discovery and HTTP resilience setup. Each host opts into the extensions it needs.",outcome:"Defaults are shared setup code, not another deployed process or a library of business models.",sources:["defaults"]},
    {id:"aspire-integrations",title:"Integrations have two sides",claim:"Hosting describes the resource. Application code configures its client.",visual:columns('<section class="comparison"><h2>AppHost · resource orchestration</h2>'+code('var blobs = builder.AddAzureStorage("storage")\n    .RunAsEmulator().AddBlobs("blobs");\napi.WithReference(blobs);')+p("Aspire.Hosting.Azure.Storage models the resource and supplies the named connection.")+"</section>",'<section class="comparison"><h2>API · client registration</h2>'+code('builder.AddAzureBlobServiceClient("blobs");\n// Inject BlobServiceClient into your blob adapter.')+p("Aspire.Azure.Storage.Blobs consumes that same blobs connection. Business policy stays in the application and adapter.")+"</section>"),detail:"Use the same connection name on both sides. Hosting orchestration, client setup and business adapters have separate responsibilities; credentials and supported diagnostics still need review.",outcome:"A resource reference supplies configuration; the API must also register and use its client.",sources:["integrations","blobHosting","blobClient"]},
    {id:"aspire-observe",title:"Observe the whole request",claim:"Resource state explains startup. Telemetry explains the request.",visual:concepts([["Resources + console","State, endpoints and process output."],["Logs + traces","Structured events and correlated request paths."],["Metrics","Measurements of repeated behavior, with real units."]]),detail:"OpenTelemetry instrumentation and export must be configured. The dashboard displays the evidence it receives; it does not invent missing spans. It can also run standalone for compatible telemetry sources.",outcome:"Choose the evidence that answers the question, and verify what is actually instrumented.",sources:["dashboard","defaults"]},
    {id:"aspire-fit",title:"Where ASPIRE fits",claim:"An application model that complements your stack.",visual:concepts([["Multiple languages","Model workloads beyond .NET alongside their dependencies."],["Local workflows","Coordinate development environments and diagnostics."],["(Deployment reuse)","Reuse supported parts of the model through target-specific tooling."]]),detail:"ASPIRE does not replace application frameworks, cloud providers or production runtimes. Local emulators and managed infrastructure differ. Deployment support varies; pipeline capabilities remain version- and target-dependent.",outcome:"Separate product capabilities ready for integration.",sources:["overview","deployment"]}
  ];
  const slides = fundamentals.map(slide => ({
    ...slide,chapter:"Chapter 01",chapterNumber:1,meta:"CHAPTER 01 / ASPIRE FUNDAMENTALS",view:"fundamentals",toc:false,
    html:p(`<span class="claim">${slide.claim}</span>`)+`<div class="fundamentals-visual">${slide.visual}</div>`+p(slide.detail)
  }));
  const growth = [
    {id:"blazor-start",title:"Current application",topology:"baseline",addition:null,claim:"Blazor frontend → .NET 10 REST API"},
    ...milestones
  ];
  growth.forEach(slide => slides.push({
    ...slide,removal:null,chapter:"Chapter 03",chapterNumber:3,meta:"CHAPTER 03 / WHAT WE WILL BUILD",view:"growth",toc:false,outcome:"",
    html:p(`<span class="claim">${escape(slide.claim)}</span>`)+architecture(slide.topology,slide.addition)
  }));
  // Chapters 05–11 show implemented deltas; Chapter 12 retains proposed SignalR wiring.
  const milestoneCode = {
    apphost: [
      {id:"apphost-projects",file:"WorkshopHub.sln · new project setup",context:"Create new projects using the ASPIRE templates.",text:`dotnet new install Aspire.ProjectTemplates::13.6.5
dotnet new aspire-apphost -n WorkshopHub.AppHost --no-restore
dotnet new aspire-servicedefaults -n WorkshopHub.AppHost.ServiceDefaults --no-restore
dotnet sln WorkshopHub.sln add WorkshopHub.AppHost/WorkshopHub.AppHost.csproj
dotnet sln WorkshopHub.sln add WorkshopHub.AppHost.ServiceDefaults/WorkshopHub.AppHost.ServiceDefaults.csproj`,note:"Because package versions are managed centrally in Directory.Packages.props: adding the above projects means updating their .csproj files is required by removing the Version attribute from every PackageReference.",noteEmphasis:true},
      {id:"apphost-project",file:"WorkshopHub.AppHost/WorkshopHub.AppHost.csproj",highlights:['<Sdk Name="Aspire.AppHost.Sdk" Version="13.6.5" />', '<IsAspireHost>true</IsAspireHost>'],text:`<Project Sdk="Microsoft.NET.Sdk">
  <Sdk Name="Aspire.AppHost.Sdk" Version="13.6.5" />
  <PropertyGroup>
    <OutputType>Exe</OutputType>
    <IsAspireHost>true</IsAspireHost>
    <AspireUseCliBundle>true</AspireUseCliBundle>
  </PropertyGroup>
  <ItemGroup>
    <ProjectReference Include="../WorkshopHub.Api/WorkshopHub.Api.csproj" />
    <ProjectReference Include="../WorkshopHub.Web/WorkshopHub.Web.csproj" />
  </ItemGroup>
</Project>`},
      {id:"apphost-code",file:"WorkshopHub.AppHost/AppHost.cs",context:"Register the original frontend and backend project into ASPIRE",highlights:["builder.AddProject"],text:`var builder = DistributedApplication.CreateBuilder(args);

var backendApi = builder.AddProject<Projects.WorkshopHub_Api>("backendApi")
    .WithHttpHealthCheck("/health");

builder.AddProject<Projects.WorkshopHub_Web>("frontend")
    .WithReference(backendApi)
    .WaitFor(backendApi)
    .WithHttpHealthCheck("/health");

builder.Build().Run();`},
      {id:"apphost-api",file:"WorkshopHub.Api/Program.cs",context:"Insert AddServiceDefaults after builder creation; replace only the old /health mapping at the end.",highlights:["builder.AddServiceDefaults();", "app.MapDefaultEndpoints();"],text:`var builder = WebApplication.CreateBuilder(args);
builder.AddServiceDefaults();
builder.Services.AddControllers();
builder.Services.AddOpenApi();
builder.Services.AddProblemDetails();
...
app.MapControllers();
app.MapOpenApi();
app.MapDefaultEndpoints();
app.Run();`},
      {id:"apphost-web",file:"WorkshopHub.Web/Program.cs",context:`Insert AddServiceDefaults after builder creation; replace only the old /health mapping at the end;
	  Replace the typed client’s fixed ApiBaseUrl assignment.`,highlights:["builder.AddServiceDefaults();", "https+http://backendApi", "app.MapDefaultEndpoints();"],text:`var builder = WebApplication.CreateBuilder(args);
builder.AddServiceDefaults();

builder.WebHost.UseStaticWebAssets();
builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.AddSingleton<DisplayFormatting>();
builder.Services.AddHttpClient<BookingApiClient>(client =>
{
    client.BaseAddress = new Uri("https+http://backendApi");
    client.Timeout = TimeSpan.FromSeconds(30);
});
...
app.MapRazorComponents<App>().AddInteractiveServerRenderMode();
app.MapDefaultEndpoints();
app.Run();`,note:"The named API reference supplies endpoint discovery."}
    ],
    sql: [
      {id:"sql-versions",file:"Directory.Packages.props",context:"Add hosting and EF provider versions.",highlights:['<PackageVersion Include="Aspire.Hosting.SqlServer" Version="13.6.5" />', '<PackageVersion Include="Microsoft.EntityFrameworkCore.SqlServer" Version="10.0.15" />'],text:`...
<ItemGroup>
  <PackageVersion Include="Aspire.Hosting.SqlServer" Version="13.6.5" />
  <PackageVersion Include="Microsoft.EntityFrameworkCore.SqlServer" Version="10.0.15" />
  ...
</ItemGroup>`},
      {id:"sql-package",file:"WorkshopHub.AppHost/WorkshopHub.AppHost.csproj",highlights:['<PackageReference Include="Aspire.Hosting.SqlServer" />'],text:`...
<ItemGroup>
  <PackageReference Include="Aspire.Hosting.SqlServer" />
  ...
</ItemGroup>`,additionalExamples:[{file:"WorkshopHub.Infrastructure/WorkshopHub.Infrastructure.csproj",context:"Replace the SQLite provider and native bundle with the SQL Server EF provider.",highlights:['<PackageReference Include="Microsoft.EntityFrameworkCore.SqlServer" />'],text:`...
<ItemGroup>
  <PackageReference Include="Microsoft.EntityFrameworkCore.SqlServer" />
  ...
</ItemGroup>`}]},
      {id:"sql-code",file:"WorkshopHub.AppHost/AppHost.cs",context:"Add SQL before backendApi; reference the database and wait for readiness.",highlights:['var database = builder.AddSqlServer("sqlServer")', '.WithDataVolume()', '.AddDatabase("database")', '.WithReference(database)', '.WaitFor(database)'],text:`...
var database = builder.AddSqlServer("sqlServer")
    .WithDataVolume()
    .AddDatabase("database");

var backendApi = builder.AddProject<Projects.WorkshopHub_Api>("backendApi")
    .WithReference(database)
    .WaitFor(database)
    .WithHttpHealthCheck("/health");
...`,note:`SQLite persistence moves to a separate SQL Server resource with a developer data volume.
Database readiness does not apply the schema.`},
      {id:"sql-api",file:"WorkshopHub.Api/Program.cs",context:"Replace SQLite path/setup; retain the existing application and EF store registrations.",highlights:['using WorkshopHub.Infrastructure.Persistence;', 'builder.Configuration.GetConnectionString("database")', 'builder.EnrichSqlServerDbContext<DatabaseContext>();'],text:`using WorkshopHub.Infrastructure.Persistence;
...
var connectionString = builder.Configuration.GetConnectionString("database")
    ?? throw new InvalidOperationException("Run through WorkshopHub.AppHost; connection 'database' is required.");
builder.Services.AddWorkshopApplicationServices();
builder.Services.AddWorkshopSqlServerPersistence(connectionString);
builder.EnrichSqlServerDbContext<DatabaseContext>();
...`,note:`Enrich the already-registered DatabaseContext; do not add a competing context. 
Health checks can pass with an empty database—course but queries requires migrations.`}
    ],
    migrator: [
      {id:"migrator-project",file:"WorkshopHub.Migrator/WorkshopHub.Migrator.csproj",context:`New project: Reference Infrastructure and ServiceDefaults.
	  Reference the package for the background process.`,highlights:['<PackageReference Include="Microsoft.Extensions.Hosting" />', '<ProjectReference Include="../WorkshopHub.AppHost.ServiceDefaults/WorkshopHub.AppHost.ServiceDefaults.csproj" />'],text:`...
<ItemGroup>
  <PackageReference Include="Microsoft.Extensions.Hosting" />
  <ProjectReference Include="../WorkshopHub.Infrastructure/WorkshopHub.Infrastructure.csproj" />
  <ProjectReference Include="../WorkshopHub.AppHost.ServiceDefaults/WorkshopHub.AppHost.ServiceDefaults.csproj" />
</ItemGroup>
...`,additionalExamples:[{file:"WorkshopHub.AppHost/WorkshopHub.AppHost.csproj",context:"Reference the migrator project on the AppHost.",highlights:['<ProjectReference Include="../WorkshopHub.Migrator/WorkshopHub.Migrator.csproj" />'],text:`...
<ProjectReference Include="../WorkshopHub.Migrator/WorkshopHub.Migrator.csproj" />
...`}],note:""},
      {id:"migrator-code",file:"WorkshopHub.AppHost/AppHost.cs",context:"Insert after the SQL resource; gate the existing backend on successful completion.",highlights:['builder.AddProject<Projects.WorkshopHub_Migrator>("migrations")', '.WaitForCompletion(migrations)'],text:`...
var migrations = builder.AddProject<Projects.WorkshopHub_Migrator>("migrations")
    .WithReference(database)
    .WaitFor(database);

var backendApi = builder.AddProject<Projects.WorkshopHub_Api>("backendApi")
    .WithReference(database)
    .WaitFor(database)
    .WaitForCompletion(migrations)
    .WithHttpHealthCheck("/health");
...`,note:"Finished with exit code 0 — not process readiness."},
      {id:"migrator-history",title:"THE CODE: OOPS SOMEHTING WHENT WRONG",file:"WorkshopHub.Infrastructure/Persistence/Migrations/SqlServer/202611070001_InitialBookings.cs",context:"BuildTargetModel: declare the typed property before using it as the key in the historical string-based model.",highlights:['booking.Property<Guid>("Id");'],text:`...
modelBuilder.Entity("WorkshopHub.Domain.Booking", booking =>
{
    booking.Property<Guid>("Id");
    booking.HasKey("Id");
    ...
});
...`,note:"Fix the existing declaration order; preserve the migration identity and schema."},
      {id:"migrator-startup",file:"WorkshopHub.Migrator/Program.cs",context:"Register the existing DatabaseContext and the one-shot worker on a generic host.",highlights:['builder.AddServiceDefaults();', 'builder.EnrichSqlServerDbContext<DatabaseContext>();', 'builder.Services.AddHostedService<MigrationWorker>();'],text:`...
var builder = Host.CreateApplicationBuilder(args);
builder.AddServiceDefaults();
var connectionString = builder.Configuration.GetConnectionString("database")
    ?? throw new InvalidOperationException("Connection 'database' is required.");
builder.Services.AddWorkshopSqlServerPersistence(connectionString);
builder.EnrichSqlServerDbContext<DatabaseContext>();
builder.Services.AddHostedService<MigrationWorker>();
...
await builder.Build().RunAsync();`,note:"The worker applies Infrastructure’s existing SQL Server schema migrations."},
      {id:"migrator-execution",file:"WorkshopHub.Migrator/MigrationWorker.cs",context:"Inside ExecuteAsync: resolve the scoped context and apply its migrations.",highlights:['db.Database.MigrateAsync(stoppingToken)'],text:`...
await using var scope = services.CreateAsyncScope();
var db = scope.ServiceProvider.GetRequiredService<DatabaseContext>();
await db.Database.CreateExecutionStrategy().ExecuteAsync(async () =>
{
    await db.Database.MigrateAsync(stoppingToken);
});
...`,note:"Inject IServiceProvider as services, IHostApplicationLifetime as lifetime and ILogger<MigrationWorker> as logger into this BackgroundService."},
      {id:"migrator-lifetime",file:"WorkshopHub.Migrator/MigrationWorker.cs",context:"Wrap the migration execution: report failure and always stop the one-shot host.",highlights:['Environment.ExitCode = 1;', 'lifetime.StopApplication();'],text:`...
try
{
    ...
    logger.LogInformation("Database migrations completed successfully.");
}
catch (Exception exception)
{
    Environment.ExitCode = 1;
    logger.LogError(exception, "Database migration failed.");
}
finally
{
    lifetime.StopApplication();
}
...`,note:`A hosted worker does not end the host by returning.
StopApplication ends it; a failure exits nonzero so the API completion gate stays closed.`}
    ],
    seeding: [
      {id:"seeding-project",file:"WorkshopHub.Seeder/WorkshopHub.Seeder.csproj",context:"New project: Reference Infrastructure and ServiceDefaults.",highlights:['<ProjectReference Include="../WorkshopHub.AppHost.ServiceDefaults/WorkshopHub.AppHost.ServiceDefaults.csproj" />'],text:`<Project Sdk="Microsoft.NET.Sdk.Web">
  <ItemGroup>
    <ProjectReference Include="../WorkshopHub.Infrastructure/WorkshopHub.Infrastructure.csproj" />
    <ProjectReference Include="../WorkshopHub.AppHost.ServiceDefaults/WorkshopHub.AppHost.ServiceDefaults.csproj" />
  </ItemGroup>
  ...
</Project>`,additionalExamples:[{file:"WorkshopHub.AppHost/WorkshopHub.AppHost.csproj", context:"Reference the seeder project on the AppHost.",highlights:['<ProjectReference Include="../WorkshopHub.Seeder/WorkshopHub.Seeder.csproj" />'],text:`...
<ProjectReference Include="../WorkshopHub.Seeder/WorkshopHub.Seeder.csproj" />
...`}]},
      {id:"seeding-code",file:"WorkshopHub.AppHost/AppHost.cs",context:"Inside a local Development run; the API does not wait for Seeder.",highlights:['.WithEnvironment("Workshop__EnableSeeding", "true")', '.WithHttpEndpoint(name: "http")'],text:`...
if (builder.ExecutionContext.IsRunMode && builder.Environment.IsDevelopment())
{
    builder.AddProject<Projects.WorkshopHub_Seeder>("seeder")
        .WithReference(database)
        .WaitFor(database)
        .WaitForCompletion(migrations)
        .WithEnvironment("ASPNETCORE_ENVIRONMENT", "Development")
        .WithEnvironment("Workshop__EnableSeeding", "true")
        .WithHttpEndpoint(name: "http")
        .WithHttpHealthCheck("/health")
        ...
}
...`,note:"Seeder stays running for manual commands; it does not execute on startup."},
      {id:"seeding-commands",file:"WorkshopHub.AppHost/AppHost.cs",context:"Continue the same resource chain with one destructive dashboard command.",highlights:['.WithHttpCommand("/seed"'],text:`...
    .WithHttpCommand("/seed", "Reset and seed", endpointName: "http", commandOptions: new()
    {
        Method = HttpMethod.Post,
        IconName = "Sparkle",
        ResultMode = HttpCommandResultMode.Json,
        ConfirmationMessage = "Drop the entire database, apply all migrations, and restore the original course catalog? All existing data will be lost."
    });
...`,note:`Use Aspire.Hosting.ApplicationModel for HttpCommandResultMode.
Confirmation warns that all existing data will be lost.`},
      {id:"seeding-startup",file:"WorkshopHub.Seeder/Program.cs",context:"Require Development and explicit enablement before registering persistence.",highlights:['!builder.Environment.IsDevelopment()', '!builder.Configuration.GetValue<bool>("Workshop:EnableSeeding")'],text:`...
var builder = WebApplication.CreateBuilder(args);
if (!builder.Environment.IsDevelopment() ||
    !builder.Configuration.GetValue<bool>("Workshop:EnableSeeding"))
{
    throw new InvalidOperationException(
        "Seeder is only available in an explicitly enabled local Development run.");
}
...`,note:"AppHost supplies both settings. This startup guard prevent exposing the Seeder to untrusted clients."},
      {id:"seeding-persistence",file:"WorkshopHub.Seeder/Program.cs",context:"Register the existing context and map one POST endpoint to SeedDataset.",highlights:['builder.EnrichSqlServerDbContext<DatabaseContext>();', 'builder.Services.AddScoped<SeedDataset>();', 'app.MapPost("/seed"', 'dataset.ApplyAsync(token)'],text:`...
builder.AddServiceDefaults();
builder.Services.AddProblemDetails();
var connectionString = builder.Configuration.GetConnectionString("database")
    ?? throw new InvalidOperationException("Connection 'database' is required.");
builder.Services.AddWorkshopSqlServerPersistence(connectionString);
builder.EnrichSqlServerDbContext<DatabaseContext>();
builder.Services.AddScoped<SeedDataset>();
...
app.UseExceptionHandler();
app.MapDefaultEndpoints();
app.MapPost("/seed", async (SeedDataset dataset, CancellationToken token) =>
    Results.Ok(await dataset.ApplyAsync(token)));
...
app.Run();`,note:""},
      {id:"seeding-dataset",file:"WorkshopHub.Seeder/SeedDataset.cs",context:"Drop the database and reapply schema migrations before restoring the original catalog.",highlights:['CreateExecutionStrategy().ExecuteAsync', 'EnsureDeletedAsync(token)', 'MigrateAsync(token)'],text:`public Task<SeedResponse> ApplyAsync(CancellationToken token) =>
    database.Database.CreateExecutionStrategy().ExecuteAsync(async () =>
    {
        database.ChangeTracker.Clear();
        await database.Database.EnsureDeletedAsync(token);
        await database.Database.MigrateAsync(token);
        ...`,note:"The original course data from the migrations now lives in the optional Seeder: four original courses with their original IDs, descriptions, prices and capacities. No bookings are seeded; courses start unarchived, at revision zero, with zero occupied seats. Every reset discards all existing data."}
    ],
    blobs: [
      {id:"blobs-versions",file:"Directory.Packages.props",context:`Add hosting and Storage packages.
	  The ticket adapter installs the Chromium shipped with Playwright.`,highlights:['<PackageVersion Include="Aspire.Hosting.Azure.Storage" Version="13.6.5" />', '<PackageVersion Include="Aspire.Azure.Storage.Blobs" Version="13.6.5" />', '<PackageVersion Include="Microsoft.Playwright" Version="1.64.1" />'],text:`...
<ItemGroup>
  <PackageVersion Include="Aspire.Hosting.Azure.Storage" Version="13.6.5" />
  <PackageVersion Include="Aspire.Azure.Storage.Blobs" Version="13.6.5" />
  <PackageVersion Include="Microsoft.Playwright" Version="1.64.1" />
  ...
</ItemGroup>`},
      {id:"blobs-packages",file:"WorkshopHub.AppHost/WorkshopHub.AppHost.csproj",context:"The AppHost models storage here; the API acquires only the client and printer.",highlights:['<PackageReference Include="Aspire.Hosting.Azure.Storage" />', '<PackageReference Include="Aspire.Azure.Storage.Blobs" />', '<PackageReference Include="Microsoft.Playwright" />'],text:`...
<ItemGroup>
  <PackageReference Include="Aspire.Hosting.Azure.Storage" />
  ...
</ItemGroup>`,additionalExamples:[{file:"WorkshopHub.Infrastructure.Tickets/WorkshopHub.Infrastructure.Tickets.csproj",context:"New project referenced by the API. Chromium is installed by deploy-time tooling, not at request time.",highlights:['<PackageReference Include="Aspire.Azure.Storage.Blobs" />', '<PackageReference Include="Microsoft.Playwright" />'],text:`<Project Sdk="Microsoft.NET.Sdk">
  <ItemGroup>
    <FrameworkReference Include="Microsoft.AspNetCore.App" />
    <ProjectReference Include="../WorkshopHub.Application/WorkshopHub.Application.csproj" />
    <PackageReference Include="Aspire.Azure.Storage.Blobs" />
    <PackageReference Include="Microsoft.Playwright" />
  </ItemGroup>
  <ItemGroup>
    <EmbeddedResource Include="Templates/TicketTemplate.html" />
  </ItemGroup>
</Project>`}]},
      {id:"blobs-code",file:"WorkshopHub.AppHost/AppHost.cs",context:"Register persistent storage before backendApi; only the API references the container.",highlights:['var storage = builder.AddAzureStorage("storage")', '.WithDataVolume()', '.WithBlobPort(10000)', 'var tickets = storage.AddBlobContainer("tickets")', '.WithReference(tickets)', '.WaitFor(storage)'],text:`...
var storage = builder.AddAzureStorage("storage")
    .RunAsEmulator(container =>
    {
        container.WithDataVolume();
        container.WithBlobPort(10000);
    });
var tickets = storage.AddBlobContainer("tickets");

var backendApi = builder.AddProject<Projects.WorkshopHub_Api>("backendApi")
    ...
    .WithReference(tickets)
    .WaitFor(storage);
...`,note:`Azurite persists its data volume, so locally generated PDFs survive an AppHost restart.
tickets is the container resource, not a second container: it runs inside storage.`},
      {id:"blobs-api",file:"WorkshopHub.Api/Program.cs",context:"Register the ticket adapters, then create the private container before serving.",highlights:['builder.AddWorkshopTicketIntegrations();', 'app.Services.EnsureTicketStorageAsync().GetAwaiter().GetResult();'],text:`...
builder.AddWorkshopTicketIntegrations();

var app = builder.Build();
...
app.Services.EnsureTicketStorageAsync().GetAwaiter().GetResult();
...`,additionalExamples:[{file:"WorkshopHub.Infrastructure.Tickets/DependencyInjection.cs",context:"The whole storage wiring: one Aspire client registration and two adapters.",highlights:['builder.AddAzureBlobContainerClient("tickets");', 'ITicketRenderer, PlaywrightTicketRenderer', 'ITicketBlobStore, AzureTicketBlobStore'],text:`...
public static IHostApplicationBuilder AddWorkshopTicketIntegrations(this IHostApplicationBuilder builder)
{
    builder.AddAzureBlobContainerClient("tickets");
    builder.Services.AddSingleton<ITicketRenderer, PlaywrightTicketRenderer>();
    builder.Services.AddSingleton<ITicketBlobStore, AzureTicketBlobStore>();
    return builder;
}
...`}],note:'The "Tickets" lookup resolves the lowercase tickets connection. Migrator and Seeder never take this dependency.'},
      {id:"blobs-web",file:"WorkshopHub.Web/Program.cs",context:"Same-origin download route. It needs the typed client and its discovery address.",highlights:['builder.Services.AddBookingApiClient();', 'app.MapTicketDownloads();'],text:`...
builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.AddSingleton<DisplayFormatting>();
builder.Services.AddBookingApiClient();
...
app.MapRazorComponents<App>().AddInteractiveServerRenderMode();
app.MapTicketDownloads();`,additionalExamples:[{file:"WorkshopHub.Web/Endpoints/TicketDownloads.cs",context:"Relays the PDF; the browser never learns the API or storage location.",highlights:['public const string Route = "/admin/tickets/{ticketId:guid}/download";', 'await bookingApi.OpenTicketPdfAsync(ticketId, cancellationToken)'],text:`...
public const string Route = "/admin/tickets/{ticketId:guid}/download";

internal static async Task DownloadAsync(Guid ticketId, BookingApiClient bookingApi, HttpContext context)
{
    ...
    upstream = await bookingApi.OpenTicketPdfAsync(ticketId, cancellationToken);
    ...
}`}],note:"Same-origin forwarding keeps storage credentials and private blob URLs out of Web and the browser."}
    ],
    servicebus: [
      {id:"servicebus-versions",file:"Directory.Packages.props",context:"Add broker hosting and client packages; retain the existing storage and PDF renderer versions.",highlights:['Aspire.Hosting.Azure.ServiceBus', 'Aspire.Azure.Messaging.ServiceBus', 'Azure.Messaging.ServiceBus'],text:`...
<ItemGroup>
  <PackageVersion Include="Aspire.Hosting.Azure.ServiceBus" Version="13.6.5" />
  <PackageVersion Include="Aspire.Azure.Messaging.ServiceBus" Version="13.6.5" />
  <PackageVersion Include="Azure.Messaging.ServiceBus" Version="7.20.2" />
  <PackageVersion Include="Aspire.Azure.Storage.Blobs" Version="13.6.5" />
  <PackageVersion Include="Microsoft.Playwright" Version="1.64.1" />
  ...
</ItemGroup>`},
      {id:"servicebus-packages",columns:true,file:"WorkshopHub.AppHost/WorkshopHub.AppHost.csproj",context:"Hosting belongs in AppHost; sender and processor SDKs belong in the messaging adapter.",highlights:['<PackageReference Include="Aspire.Hosting.Azure.ServiceBus" />', '<PackageReference Include="Aspire.Azure.Messaging.ServiceBus" />', '<PackageReference Include="Azure.Messaging.ServiceBus" />'],text:`...
<PackageReference Include="Aspire.Hosting.Azure.ServiceBus" />
<ProjectReference Include="..\\WorkshopHub.Contracts\\WorkshopHub.Contracts.csproj" IsAspireProjectResource="false" />
<ProjectReference Include="..\\WorkshopHub.ServiceBusProcessor\\WorkshopHub.ServiceBusProcessor.csproj" />
...`,additionalExamples:[{file:"WorkshopHub.Infrastructure.Messaging/WorkshopHub.Infrastructure.Messaging.csproj",context:"New adapter project references Application and Contracts.",highlights:['<PackageReference Include="Aspire.Azure.Messaging.ServiceBus" />', '<PackageReference Include="Azure.Messaging.ServiceBus" />'],text:`...
<ProjectReference Include="../WorkshopHub.Application/WorkshopHub.Application.csproj" />
<ProjectReference Include="../WorkshopHub.Contracts/WorkshopHub.Contracts.csproj" />
<PackageReference Include="Aspire.Azure.Messaging.ServiceBus" />
<PackageReference Include="Azure.Messaging.ServiceBus" />
...`},{file:"WorkshopHub.ServiceBusProcessor/WorkshopHub.ServiceBusProcessor.csproj",context:"Worker references Application, Contracts, Messaging, Tickets and ServiceDefaults; no SQL Infrastructure or API project.",highlights:['WorkshopHub.Infrastructure.Messaging', 'WorkshopHub.Infrastructure.Tickets'],text:`...
<ProjectReference Include="..\\WorkshopHub.Infrastructure.Messaging\\WorkshopHub.Infrastructure.Messaging.csproj" />
<ProjectReference Include="..\\WorkshopHub.Infrastructure.Tickets\\WorkshopHub.Infrastructure.Tickets.csproj" />
...`}]},
      {id:"servicebus-code",file:"WorkshopHub.AppHost/AppHost.cs",context:"Create one topic before the hosts; each subscription declares a Subject correlation rule.",highlights:['ServiceBusTopology.ConnectionName', 'ServiceBusTopology.Topic', 'CorrelationFilter', 'TicketMessageSubjects.GenerateTicket', 'TicketMessageSubjects.TicketGenerated'],text:`...
var serviceBus = builder.AddAzureServiceBus(ServiceBusTopology.ConnectionName)
    .RunAsEmulator();
var topic = serviceBus.AddServiceBusTopic(ServiceBusTopology.Topic);
GeneratorSubscription(topic);
PersistenceSubscription(topic);
...
static void GeneratorSubscription(IResourceBuilder<AzureServiceBusTopicResource> topic) =>
    topic.AddServiceBusSubscription(ServiceBusTopology.GeneratorSubscription, ServiceBusTopology.GeneratorSubscription)
        .WithProperties(subscription => subscription.Rules.Add(new AzureServiceBusRule("GenerateTicketCommand")
        {
            CorrelationFilter = new AzureServiceBusCorrelationFilter { Subject = TicketMessageSubjects.GenerateTicket }
        }));
...
static void PersistenceSubscription(IResourceBuilder<AzureServiceBusTopicResource> topic) =>
    topic.AddServiceBusSubscription(ServiceBusTopology.PersistenceSubscription, ServiceBusTopology.PersistenceSubscription)
        .WithProperties(subscription => subscription.Rules.Add(new AzureServiceBusRule("TicketGeneratedEvent")
        {
            CorrelationFilter = new AzureServiceBusCorrelationFilter { Subject = TicketMessageSubjects.TicketGenerated }
        }));`,note:""},
      {id:"servicebus-wiring",file:"WorkshopHub.AppHost/AppHost.cs",context:"Register both hosts before Build/Run. The PDF worker references only storage and broker.",highlights:['.WithReference(serviceBus)', '.WithReference(tickets)', '"serviceBusProcessor"'],text:`...
var backendApi = builder.AddProject<Projects.WorkshopHub_Api>("backendApi")
    .WithReference(database)
    ...
    .WithReference(tickets)
    .WaitFor(storage)
    .WithReference(serviceBus)
    .WaitFor(serviceBus)
    .WithHttpHealthCheck("/health");
...
builder.AddProject<Projects.WorkshopHub_ServiceBusProcessor>("serviceBusProcessor")
    .WithReference(serviceBus)
    .WaitFor(serviceBus)
    .WithReference(tickets)
    .WaitFor(storage)
    ...;
...
builder.Build().Run();`,note:"Frontend waits for the API, not PDF completion. A queued ticket becomes downloadable after the API persists the completion event."},
      {id:"servicebus-contracts",columns:true,file:"WorkshopHub.Contracts/Messaging/CommandMessage.cs",context:"Version 1 command carries render input and stable identity, never PDF bytes or a storage key.",highlights:['Version = 1', 'IssuedAt', 'AttendeeName', 'CourseTitle', 'PriceCents'],text:`...
public const int Version = 1;
...
public sealed record CommandMessage(
    int Version, string Subject,
    Guid TicketId, Guid BookingId, Guid CourseId,
    DateTimeOffset IssuedAt,
    string AttendeeName, string CourseTitle, int PriceCents);`,additionalExamples:[{file:"WorkshopHub.Contracts/Messaging/EventMessage.cs",context:"Completion carries the same identity plus observed blob properties.",highlights:['long Length', 'string ETag'],text:`...
public sealed record EventMessage(
    int Version, string Subject,
    Guid TicketId, Guid BookingId, Guid CourseId,
    DateTimeOffset IssuedAt, long Length, string ETag);`},{file:"WorkshopHub.Contracts/Messaging/ServiceBusTopology.cs",context:"Share the exact connection, topic, subscription and Subject names.",highlights:['ConnectionName = "serviceBus"', 'Topic = "ticket"', 'GenerateTicket = "GenerateTicket"', 'TicketGenerated = "TicketGenerated"'],text:`...
public const string ConnectionName = "serviceBus";
public const string Topic = "ticket";
public const string GeneratorSubscription = "ticket-generator";
public const string PersistenceSubscription = "ticket-persistence";
...
public const string GenerateTicket = "GenerateTicket";
public const string TicketGenerated = "TicketGenerated";
...`}],note:"Receivers validate the envelope Subject and Version."},
      {id:"servicebus-publisher",file:"WorkshopHub.Infrastructure.Messaging/ServiceBusTicketPublisher.cs",context:"Both overloads serialize their envelope and send to the same topic; broker Subject selects the subscription.",highlights:['TicketMessages.Serialize(message)', 'client.CreateSender(ServiceBusTopology.Topic)', 'Subject = subject', 'ContentType = "application/json"'],text:`...
public Task<ErrorOr<Success>> PublishAsync(CommandMessage message, CancellationToken cancellationToken) =>
    SendAsync(message.Subject, TicketMessages.Serialize(message), RequestTimeout, cancellationToken);
...
await using var sender = client.CreateSender(ServiceBusTopology.Topic);
await sender.SendMessageAsync(new ServiceBusMessage(BinaryData.FromString(body))
{
    Subject = subject,
    ContentType = "application/json"
}, budget.Token);
...`,additionalExamples:[{file:"WorkshopHub.Contracts/Messaging/TicketMessages.cs",context:"Contracts use System.Text.Json without an Azure SDK dependency.",highlights:['JsonSerializerDefaults.Web', 'JsonSerializer.Serialize(message, Options)'],text:`...
private static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web);
public static string Serialize<T>(T message) => JsonSerializer.Serialize(message, Options);
...`}],note:"The EventMessage overload uses the same sender. No explicit MessageId or CorrelationId is set; no broker duplicate detection is configured."},
      {id:"servicebus-api",file:"WorkshopHub.Api/Program.cs",context:"Replace the combined storage/renderer integration; retain existing application and SQL registrations.",highlights:['builder.AddWorkshopTicketStorage();', 'builder.AddWorkshopServiceBusClient();', 'builder.AddWorkshopTicketPublisher();', 'builder.Services.AddWorkshopTicketPersistenceServices();', 'builder.AddWorkshopTicketPersistence();'],text:`...
builder.Services.AddWorkshopApplicationServices();
builder.Services.AddWorkshopSqlServerPersistence(connectionString);
builder.EnrichSqlServerDbContext<DatabaseContext>();
...
builder.AddWorkshopTicketStorage();
builder.AddWorkshopServiceBusClient();
builder.AddWorkshopTicketPublisher();
builder.Services.AddWorkshopTicketPersistenceServices();
builder.AddWorkshopTicketPersistence();
...
app.Services.EnsureTicketStorageAsync().GetAwaiter().GetResult();
...`,note:"API submits commands, consumes completion events and owns SQL metadata. It no longer registers AddWorkshopTicketRenderer; Migrator and Seeder remain storage/broker-free."},
      {id:"servicebus-worker",file:"WorkshopHub.ServiceBusProcessor/Program.cs",context:"Register broker, private storage and renderer in the worker host; generation gets a scoped service.",highlights:['builder.AddWorkshopTicketRenderer();', 'AddScoped<TicketGenerationService>()', 'builder.AddWorkshopTicketGeneration();', 'await app.Services.EnsureTicketStorageAsync();'],text:`...
builder.AddServiceDefaults();
builder.AddWorkshopServiceBusClient();
builder.AddWorkshopTicketStorage();
builder.AddWorkshopTicketRenderer();
...
builder.Services.AddScoped<TicketGenerationService>();
builder.AddWorkshopTicketGeneration();
var app = builder.Build();
await app.Services.EnsureTicketStorageAsync();
app.MapDefaultEndpoints();
await app.RunAsync();
...`,note:"The worker has no SQL connection and no API reference. DependencyInjection.cs registers the command processor and completion-event publisher."},
      {id:"servicebus-request",columns:true,file:"WorkshopHub.Application/Services/TicketRequestService.cs",context:"After eligibility and confirmation commit, answer from SQL or submit the same ticket identity.",highlights:['TicketRequestState.Ready', 'TicketId.ForBooking(bookingId)', 'publisher.PublishAsync(message, cancellationToken)', 'TicketRequestState.Queued', 'source.ConfirmedAt'],text:`...
var existing = await queryExecutor.FindForBookingAsync(bookingId, cancellationToken);
if (existing is not null)
{
    return new TicketRequest(existing.Id, TicketRequestState.Ready, existing);
}
var message = Command(source!, TicketId.ForBooking(bookingId));
...
var published = await publisher.PublishAsync(message, cancellationToken);
...
return new TicketRequest(new TicketId(message.TicketId), TicketRequestState.Queued, null);
...
source.ConfirmedAt ?? throw new InvalidOperationException("A confirmed booking must have a confirmation time."),
...`,additionalExamples:[{file:"WorkshopHub.Api/Controllers/Admin/AdminTicketsController.cs",context:"Manual issuance returns 200 Ready or 202 Queued; booking confirmation itself returns 200.",highlights:['? Ok(TicketRequest(request))', ': Accepted(TicketRequest(request))'],text:`...
return request.State == TicketRequestState.Ready
    ? Ok(TicketRequest(request))
    : Accepted(TicketRequest(request));
...`}]},
      {id:"servicebus-generation",columns:true,file:"WorkshopHub.Application/Services/TicketGenerationService.cs",context:"Inspect the derived blob key, reuse a matching generation or render/upload, then publish completion.",highlights:['stored.Matches(identity)', 'Recovered(storageKey, stored)', 'RenderAndUploadAsync(command, identity, storageKey, cancellationToken)', 'publisher.PublishAsync(completion, cancellationToken)', 'TicketGenerationOutcome.Completed'],text:`...
var stored = await blobStore.TryGetPropertiesAsync(storageKey, cancellationToken);
TicketBlobReference? reference;
if (stored is not null)
{
    if (!stored.Matches(identity)) { ... }
    reference = Recovered(storageKey, stored);
}
else
{
    reference = await RenderAndUploadAsync(command, identity, storageKey, cancellationToken);
}
...
var completion = Completion(command, reference);
...
var published = await publisher.PublishAsync(completion, cancellationToken);
if (published.IsError) { return new(TicketGenerationOutcome.Transient, published.Errors); }
...
return new(TicketGenerationOutcome.Completed, completion);`,additionalExamples:[{file:"WorkshopHub.Infrastructure.Tickets/AzureTicketBlobStore.cs",context:"Upload uses the identity fingerprint and fails if the key already exists.",highlights:['IfNoneMatch = ETag.All'],text:`...
Metadata = new Dictionary<string, string> { [TicketBlobIdentity.MetadataName] = identity.Fingerprint },
Conditions = new BlobRequestConditions { IfNoneMatch = ETag.All }
...`}],note:"RenderAndUploadAsync renders the PDF then uploads create-only. Failed event publication keeps the blob: redelivery can reuse its actual length/ETag and republish before completing the command."},
      {id:"servicebus-persistence",columns:true,file:"WorkshopHub.Application/Services/TicketPersistenceService.cs",context:"Verify storage before writing metadata. Missing blob is transient; conflicting properties are terminal.",highlights:['blobStore.TryGetPropertiesAsync(storageKey, cancellationToken)', 'stored.Matches(identity)', 'stored.IsPdf', 'message.Length != stored.Length', 'stored.HasETag(message.ETag)', 'SaveAsync(created.Value, storageKey, cancellationToken)'],text:`...
var stored = await blobStore.TryGetPropertiesAsync(storageKey, cancellationToken);
if (stored is null) { ... }
if (!stored.Matches(identity)) { ... }
if (!stored.IsPdf || !stored.HasValidLength || message.Length != stored.Length || !stored.HasETag(message.ETag))
{
    ...
    return new(TicketPersistenceOutcome.Terminal, null);
}
...
return await SaveAsync(created.Value, storageKey, cancellationToken);
...`,additionalExamples:[{file:"WorkshopHub.Infrastructure/Persistence/EntityFramework/Commands/TicketStore.cs",context:"SQL-only serializable transaction rechecks eligibility/existing ticket before this insert; BookingId has a unique index.",highlights:['database.SaveChangesAsync(token)', 'transaction.CommitAsync(token)'],text:`...
database.Tickets.Add(candidate);
await database.SaveChangesAsync(token);
await transaction.CommitAsync(token);
return candidate;
...`}],note:"Repeat matching events resolve to Saved. Ambiguous commits are reconciled before cleanup; committed ticket blobs are never blindly deleted."},
      {id:"servicebus-scope",file:"WorkshopHub.Infrastructure.Messaging/TicketMessageProcessors.cs",context:"Singleton processors create a fresh async scope per delivery; both disable automatic completion.",highlights:['AutoCompleteMessages = false', 'scopeFactory.CreateAsyncScope()', 'GetRequiredService<TicketGenerationService>()', 'TicketSettlement.Complete', 'TicketSettlement.DeadLetter', 'TicketSettlement.Abandon'],text:`...
AutoCompleteMessages = false,
...
await using var scope = scopeFactory.CreateAsyncScope();
var service = scope.ServiceProvider.GetRequiredService<TicketGenerationService>();
var result = await service.GenerateAsync(command!, cancellationToken);
return result.Outcome switch
{
    TicketGenerationOutcome.Completed => TicketSettlement.Complete,
    TicketGenerationOutcome.Terminal => TicketSettlement.DeadLetter,
    _ => TicketSettlement.Abandon
};
...
await using var scope = scopeFactory.CreateAsyncScope();
var service = scope.ServiceProvider.GetRequiredService<TicketPersistenceService>();
...`,note:"Persistence uses the same per-delivery scope with TicketPersistenceService. Generator: one concurrent call, 10-minute lock renewal. Persistence: four calls, two-minute renewal. Both use PrefetchCount = 0."},
      {id:"servicebus-settlement",file:"WorkshopHub.Infrastructure.Messaging/TicketMessageProcessors.cs",context:"Complete resolved persistence outcomes; unsupported input dead-letters and transient failure abandons.",highlights:['TicketPersistenceOutcome.Saved or TicketPersistenceOutcome.Superseded or TicketPersistenceOutcome.Rejected', 'CompleteMessageAsync', 'DeadLetterMessageAsync', 'AbandonMessageAsync'],text:`...
TicketPersistenceOutcome.Saved or TicketPersistenceOutcome.Superseded or TicketPersistenceOutcome.Rejected
    => TicketSettlement.Complete,
TicketPersistenceOutcome.Terminal => TicketSettlement.DeadLetter,
_ => TicketSettlement.Abandon
...
case TicketSettlement.Complete:
    await args.CompleteMessageAsync(args.Message, args.CancellationToken).ConfigureAwait(false);
    break;
case TicketSettlement.DeadLetter:
    await args.DeadLetterMessageAsync(args.Message,
        deadLetterReason: "UnsupportedTicketMessage",
        deadLetterErrorDescription: "The message cannot become valid on retry.",
        args.CancellationToken).ConfigureAwait(false);
    break;
default:
    await args.AbandonMessageAsync(args.Message, cancellationToken: args.CancellationToken).ConfigureAwait(false);
    break;
...`,note:"HandleAsync finishes before settlement. A generation command completes after upload/event publication; an event completes after persistence or safe resolution. Shutdown cancellation leaves the delivery unsettled."}
    ],
    signalr: [
      {id:"signalr-packages",file:"Directory.Packages.props",context:"Hosting in AppHost; management SDK in API only. Browser client is bundled locally.",highlights:['Aspire.Hosting.Azure.SignalR','Microsoft.Azure.SignalR.Management','13.6.5','1.33.1'],text:`...
<PackageVersion Include="Aspire.Hosting.Azure.SignalR" Version="13.6.5" />
<PackageVersion Include="Microsoft.Azure.SignalR.Management" Version="1.33.1" />
...`,additionalExamples:[{file:"WorkshopHub.AppHost / WorkshopHub.Api · project references",text:`<PackageReference Include="Aspire.Hosting.Azure.SignalR" />
...
<PackageReference Include="Microsoft.Azure.SignalR.Management" />`,highlights:['Aspire.Hosting.Azure.SignalR','Microsoft.Azure.SignalR.Management']}],note:"Web bundles @microsoft/signalr 10.0.0 and its MIT license; no CDN or management connection in the browser."},
      {id:"signalr-code",file:"WorkshopHub.AppHost/AppHost.cs",context:"API-only management connection. Frontend still references backendApi, not SignalR.",highlights:['builder.AddAzureSignalR("notifications", AzureSignalRServiceMode.Serverless)','.RunAsEmulator();','.WithReference(notifications)','.WaitFor(notifications)'],text:`var notifications = builder.AddAzureSignalR("notifications", AzureSignalRServiceMode.Serverless)
    .RunAsEmulator();
...
var backendApi = builder.AddProject<Projects.WorkshopHub_Api>("backendApi")
    ...
    .WithReference(notifications)
    .WaitFor(notifications)
    .WithHttpHealthCheck("/health");`,note:"Serverless business notifications use a separate browser connection from Blazor’s interactive-server circuit."}
    ]
  };
  const codeSlide = (common, example) => {
    const excerpt = item => `<h2 class="code-file">${escape(item.file)}</h2>${item.context ? `<p class="code-context">${escape(item.context)}</p>` : ""}${code(item.text, item.highlights)}`;
    const main = excerpt(example);
    const extras = (example.additionalExamples || []).map(excerpt).join("");
    return {...common,id:example.id,title:example.title ?? "THE CODE",view:"code",file:example.file,html:
      (example.columns ? columns(`<div class="code-excerpts">${main}</div>`, `<div class="code-excerpts">${extras}</div>`) : main + extras)+
      (example.note ? `<p class="code-note${example.noteEmphasis ? " code-note-emphasis" : ""}">${escape(example.note)}</p>` : "")};
  };
  // Chapter 09 interleaves its explanation between AppHost and API code, then ends with the prompt, Explorer evidence and the dashboard result.
  const blobPortExplanation = common => ({...common,id:"blobs-port",title:"Why port 10000?",view:"explanation",outcome:"10000 is a local host Blob port — not an Azure production endpoint.",html:
    p('<span class="claim">Give desktop tools a predictable local Blob endpoint.</span>')+
    '<div class="fundamentals-visual">'+concepts([
      ['Local Azurite','The emulator stands in for the Azure Storage account.'],
      ['Fixed host port','The same address every time the AppHost starts.'],
      ['Injected client','The API receives configuration; it hard-codes nothing.']
    ])+'</div>'+
    columns(
      '<section class="comparison"><h2>Allocated host port</h2>'+p('Docker picks a new port each run, so a saved desktop connection stops working.')+'</section>',
      '<section class="comparison"><h2><code>.WithBlobPort(10000)</code></h2>'+p('<strong>Stable endpoint.</strong> <code>http://127.0.0.1:10000/devstoreaccount1</code> keeps working across restarts.')+'</section>'
    )+
    p('<span class="code-note"><strong>Separate concerns:</strong> <code>WithDataVolume()</code> keeps the bytes; <code>WithBlobPort(10000)</code> keeps the address.</span>')
  });
  const blobPromptText = `Extend the WorkshopHub starter with PDF tickets for confirmed bookings. Inspect and reuse any existing ticket code; preserve unrelated changes and the current architecture.

Use Aspire's existing storage emulator and tickets container, referenced only by backendApi. Generate real A4 PDFs with Playwright Chromium from self-contained, HTML-encoded markup. Include course, attendee, informational price, issuance date, booking ID and ticket ID. Store PDF bytes privately in Blob Storage and ticket metadata in SQL. Use course/ticket GUID blob keys, the existing 10 MiB limit and one persisted ticket per booking.

Commit booking confirmation before rendering or uploading. If issuance fails, keep the booking confirmed and return a safe warning with retry support. Repeated issuance must return the existing ticket; handle concurrent requests and failed persistence without deleting another request's blob.

Provide confirmation/issuance, metadata and PDF-download endpoints, reusing existing ones. Add Download/Retry to the admin UI and preserve the ticket after reload. Stream downloads through the same-origin Web endpoint; never expose storage credentials or public blob URLs. Keep long-running generation within the existing client timeout/resilience design and do not retry unsafe mutations automatically.

Reuse the current migration where present. Preserve existing data and volumes; do not reset the database or deploy Azure resources. Flag unauthenticated admin routes as a local-demo limitation. Verify real PDF bytes, metadata, repeat issuance and browser download.`;
  const blobPromptSlide = common => ({...common,id:"blobs-prompt",title:"PROMPT",view:"prompt",outcome:"Reuses the existing ticket code; asks for real PDFs, private storage and safe retry behavior.",html:
    p('<span class="claim">A prompt that asks for the ticket milestone, not a rewrite.</span>')+
    `<div class="prompt-panel"><div class="prompt-actions"><span class="prompt-label">Copy into your assistant</span><button type="button" class="prompt-copy" data-prompt-copy>Copy prompt</button></div><pre class="prompt-text">${escape(blobPromptText)}</pre></div>`
  });
  // One physical topic; arrows terminate at the topic for publication, never at a subscription.
  const ticketFlowSlide = common => {
    const marker = `ticket-flow-${++diagramNumber}`;
    const box = (x,y,w,h,title,detail) => `<g class="node changed"><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="4"/><text x="${x+18}" y="${y+32}" class="node-title">${title}</text><text x="${x+18}" y="${y+62}" class="node-detail">${detail}</text></g>`;
    const arrow = (from,to,path,label,x,y) => `<g class="edge changed" data-source="${from}" data-target="${to}"><path d="${path}" marker-end="url(#${marker})"/><text x="${x}" y="${y}" text-anchor="middle">${label}</text></g>`;
    return {...common,id:"servicebus-flow",title:"MESSAGE FLOW",view:"explanation",outcome:"Command completion means blob + event published; event completion means persistence or safe resolution.",html:
      p('<span class="claim">Publish twice to the same topic. Each Subject selects its own subscription.</span>')+
      `<figure class="architecture ticket-flow"><div class="diagram-scroll"><svg viewBox="0 0 1400 620" role="img" aria-label="API publishes GenerateTicket to ticket. Subject rules route the command to the PDF worker and TicketGenerated back to the API, which verifies the blob and saves SQL metadata."><title>Ticket command and completion flow</title><desc>One ticket topic contains ticket-generator with Subject = GenerateTicket and ticket-persistence with Subject = TicketGenerated. serviceBusProcessor creates or reuses a private PDF blob and publishes EventMessage to the same topic. Only the API writes SQL. Complete command after upload and event publication; Complete event after persistence or safe resolution. HTTP acceptance, worker completion and persisted readiness are separate boundaries.</desc>
      <defs><marker id="${marker}" markerWidth="9" markerHeight="9" refX="8" refY="4.5" orient="auto" markerUnits="userSpaceOnUse"><path d="M0 0 L9 4.5 L0 9 Z" class="arrowhead"/></marker></defs>
      <g class="orchestration"><rect x="380" y="60" width="610" height="410" rx="8"/><text x="402" y="98" class="boundary-title">Azure Service Bus · topic: ticket</text><text x="402" y="129">Both publishers send here, not to subscriptions</text></g>
      ${arrow("api","topic","M320 183 H380","1 · CommandMessage",220,137)}
      ${arrow("generator","processor","M950 231 H1040","2 · read",995,213)}
      ${arrow("processor","blobs","M1370 245 H1390 V542 H1370","3 · create / reuse private PDF",1190,400)}
      ${arrow("processor","topic","M1040 268 H1015 V318 H990","4 · EventMessage → same topic",1170,330)}
      ${arrow("persistence","api","M420 395 H320","5 · consume completion",170,445)}
      ${arrow("api","sql","M170 420 V495","6 · verify blob → save SQL",170,477)}
      ${box(30,155,290,265,"API · backendApi","Submit + persist completion")}
      <text x="48" y="255" class="node-detail">Subject = GenerateTicket</text>
      <text x="48" y="298" class="node-detail">Verify identity / length / ETag</text>
      <text x="48" y="341" class="node-detail">Complete event after</text><text x="48" y="367" class="node-detail">persistence / safe resolution</text>
      ${box(420,170,530,105,"ticket-generator","Correlation: Subject = GenerateTicket")}
      ${box(420,340,530,105,"ticket-persistence","Correlation: Subject = TicketGenerated")}
      ${box(1040,155,330,127,"serviceBusProcessor","PDF worker · no SQL")}
      <text x="1040" y="440" class="node-detail">Subject = TicketGenerated</text>
      <text x="1040" y="468" class="node-detail">Complete command after step 4</text>
      ${box(1040,495,330,95,"Private blob · tickets","{courseId}/{ticketId}.pdf")}
      ${box(30,495,290,95,"SQL ticket metadata","API-owned persistence")}
      </svg></div><figcaption>Broker routing and settlement are separate: uploading alone does not complete the command; receiving an event alone does not complete persistence.</figcaption></figure>`};
  };
  const ticketSafeguardsSlide = common => ({...common,id:"servicebus-safeguards",title:"Redelivery and the consistency gap",view:"explanation",outcome:"Application-level redelivery safeguards; no exactly-once delivery guarantee.",html:
    p('<span class="claim">Redelivery is expected. Each boundary still needs recovery.</span>')+
    '<div class="fundamentals-visual">'+concepts([
      ['Stable identity','TicketId.ForBooking and persisted ConfirmedAt keep ticket identity and issuance time stable.'],
      ['Create-only blob','IfNoneMatch = ETag.All prevents overwrites. Reuse requires matching identity and valid PDF properties.'],
      ['Unique SQL row','One ticket per BookingId. Validate the blob, recheck eligibility and reconcile ambiguous commits.']
    ])+'</div>'+
    columns(
      '<section class="comparison"><h2>Commit → send is not atomic</h2>'+p('Confirmation returns 200 after SQL commit. Broker submission can fail afterward; a warning and explicit retry resubmit the stable ticket. No outbox or atomic SQL/broker transaction is implemented.')+'</section>',
      '<section class="comparison"><h2>Manual Refresh → private download</h2>'+p('Manual issuance returns 202 Queued or 200 Ready. Use UI Refresh to reload persisted metadata. Private downloads stream same-origin through Web → API. SignalR remains proposed; admin routes are unauthenticated local-demo endpoints.')+'</section>'
    )+
    p('<span class="code-note">No configured duplicate detection or explicit MessageId/CorrelationId; no exactly-once guarantee. Runtime evidence follows in Observability.</span>')
  });
  const ticketPromptText = `Move PDF ticket generation out of the API into the WorkshopHub ServiceBusProcessor worker. Inspect and reuse existing code, preserve unrelated changes, and keep SQL persistence owned by the API.

Use the serviceBus connection and one ticket topic. Configure ticket-generator and ticket-persistence subscriptions with Subject correlation filters for GenerateTicket and TicketGenerated. Register every resource before AppHost Build/Run; check the current worker placement. Reference broker and private tickets storage from both hosts, but never SQL or the API from the worker.

Use versioned CommandMessage and EventMessage contracts, shared names, System.Text.Json, broker Subject and application/json. Derive stable ticket identity from the booking and issuance time from persisted ConfirmedAt. Commit confirmation before submission: confirmation returns 200, manual issuance returns 202 Queued or 200 Ready. Report submission failure safely without undoing confirmation.

Worker generation must reuse a matching existing PDF or render/upload create-only, then publish completion to the same topic. Keep blobs after publish failure. API processing must verify blob identity, content type, size and ETag before unique SQL persistence; reconcile ambiguous saves and protect committed blobs during cleanup.

Create a fresh scope per delivery and disable auto-completion. Complete only after successful generation/publication or resolved persistence; abandon transient failures and dead-letter terminal input. Do not claim exactly-once delivery or add an outbox silently.

Keep manual Refresh and private same-origin Web-to-API downloads; flag unauthenticated admin routes as local-demo limitations. Verify redelivery and failure boundaries; do not reset the database, delete volumes or deploy cloud resources. Distinguish source inspection from executed evidence.`;
  const ticketPromptSlide = common => ({...common,id:"servicebus-prompt",title:"PROMPT",view:"prompt",outcome:"Reuses the ticket implementation; asks for explicit recovery and honest verification.",html:
    p('<span class="claim">A prompt for the asynchronous ticket milestone, with its failure boundaries.</span>')+
    `<div class="prompt-panel"><div class="prompt-actions"><span class="prompt-label">Copy into your assistant</span><button type="button" class="prompt-copy" data-prompt-copy>Copy prompt</button></div><pre class="prompt-text">${escape(ticketPromptText)}</pre></div>`
  });
  const signalrPromptText = `Add live business notifications to WorkshopHub using the existing Serverless notifications emulator. Reuse existing code, packages and AppHost wiring; preserve the asynchronous ticket pipeline and unrelated changes.

Add IBookingNotifications.PublishAsync(Guid, CancellationToken) and an API singleton adapter. Reuse a semaphore-guarded, disposable ServiceHubContext for bookings with Transient management transport and the notifications connection. Broadcast BookingChanged with only an opaque booking ID; never send participant data.

Notify after successful BookingService create, confirm and cancel commits, and after TicketPersistenceService returns Saved. Bound notification attempts to five seconds; log failures without reversing commits, failing successful mutations or abandoning saved completion messages. Duplicate hints are safe; preserve explicit Service Bus settlement and do not claim durable delivery.

Expose Development-only POST /api/v1/notifications/negotiate returning NotificationConnection URL/token, with ten-minute tokens and no-store. Forward through Web POST /notifications/negotiate using BookingApiClient; enforce same-origin requests and relay safe failures. Keep management credentials in API only; production requires validated identity and authorized users/groups.

Bundle @microsoft/signalr 10.0.0 with its license. Share one business socket between mounted pages, separate from Blazor’s interactive-server circuit. Retry failed connections with fresh negotiation; reload authoritative REST state after connection and every hint. Never log or persist tokens.

Start JS interop in a reusable BookingLiveUpdates component after first interactive render; dispose safely during navigation/disconnection. Refresh catalog availability and admin bookings, coalescing hints and deferring while busy/loading. Reconcile ticket notices from API state; retain manual Refresh and same-origin PDF downloads.
Verify automatic booking appearance, persisted ticket download and cancellation, origin rejection and separate sockets. Do not add test cases, reset data, delete volumes or deploy Azure.`;
  const signalrPromptSlide = common => ({...common,id:"signalr-prompt",title:"PROMPT",view:"prompt",outcome:"",html:
    p('<span class="claim">A prompt for the same live booking and ticket result.</span>')+
    `<div class="prompt-panel"><div class="prompt-actions"><span class="prompt-label">Copy into your assistant</span><button type="button" class="prompt-copy" data-prompt-copy>Copy prompt</button></div><pre class="prompt-text">${escape(signalrPromptText)}</pre></div>`
  });
  const blobExplorerSlide = common => ({...common,id:"blobs-explorer",title:"AZURE STORAGE EXPLORER",view:"evidence",html:`<figure class="app-screenshot"><img src="assets/screenshots/chapter-08-storage-explorer.png" alt="Actual Microsoft Azure Storage Explorer window attached to the local emulator, showing the private tickets container, the course-id prefix b5274a15-4cac-4fd8-9c5c-ff5252a6cf01 and the generated 5caf2f95-5ebd-49ab-948d-ed79712df623.pdf blob with content type application/pdf and a size of 111.64 KiB." decoding="sync"><figcaption><span class="capture-label">Actual local capture</span> Emulator storage account → <code>tickets</code> → course prefix → the generated <code>.pdf</code>.</figcaption></figure>`});
  milestones.forEach(milestone => {
    const chapter = chapters.find(chapter => chapter.id===milestone.chapterId);
    const common = {chapter:`Chapter ${String(chapter.number).padStart(2,"0")}`,chapterNumber:chapter.number,meta:`CHAPTER ${String(chapter.number).padStart(2,"0")} / ${chapter.title.toUpperCase()}`,toc:false,outcome:""};
    slides.push({...common,id:chapter.id,title:"ARCHITECTURE CHANGE",topology:milestone.topology,addition:milestone.addition,claim:milestone.claim,view:"architecture",html:p(`<span class="claim">${escape(milestone.claim)}</span>`)+architecture(milestone.topology,milestone.addition)});
    if (chapter.id === "blobs") {
      const examples = milestoneCode.blobs;
      slides.push(codeSlide(common, examples[0]), codeSlide(common, examples[1]), codeSlide(common, examples[2]));
      slides.push(blobPortExplanation(common));
      slides.push(codeSlide(common, examples[3]), codeSlide(common, examples[4]));
      slides.push(blobPromptSlide(common), blobExplorerSlide(common));
    } else if (chapter.id === "servicebus") {
      // Keep prerequisites and AppHost code; slides 79–88 were removed from the presentation.
      milestoneCode.servicebus.slice(0, 4).forEach(example => {
        slides.push(codeSlide(common, example));
        if (example.id === "servicebus-packages") slides.push(ticketFlowSlide(common));
      });
      slides.push(ticketPromptSlide(common));
    } else if (chapter.id === "signalr") {
      milestoneCode.signalr.forEach(example => slides.push(codeSlide(common, example)));
      slides.push(signalrPromptSlide(common));
    } else {
      milestoneCode[chapter.id].forEach(example => slides.push(codeSlide(common, example)));
    }
    if (chapter.id === "apphost") slides.push({...common,id:"apphost-result",title:"THE RESULT",view:"result",html:'<figure class="app-screenshot"><img src="assets/screenshots/chapter-04-dashboard.png" alt="Actual Aspire dashboard showing the newly orchestrated backendApi and frontend projects both Running, with their project sources and local endpoint URLs fully visible." decoding="sync"></figure>'});
    if (chapter.id === "sql") {
      slides.push({...common,id:"sql-enrichment",title:"Enrich an existing DbContext",view:"explanation",outcome:"Same context. No migrations. Connectivity is not schema readiness.",html:
        p('<span class="claim">Keep your registration. Add Aspire’s operational features.</span>')+
        '<div class="fundamentals-visual">'+concepts([
          ['Health checks', 'Can the database be reached?'],
          ['Logs + traces', 'Follow SQL activity through the request.'],
          ['Transient retries', 'Retry temporary SQL failures by default.']
        ])+'</div>'+
        columns(
          '<section class="comparison"><h2><code>AddSqlServerDbContext</code></h2>'+p('<strong>Create + equip.</strong> Register, configure and enrich.')+'</section>',
          '<section class="comparison"><h2><code>EnrichSqlServerDbContext</code></h2>'+p('<strong>Equip what already exists.</strong> Enrich your registered context.')+'</section>'
        )+
        p('<span class="code-note"><strong>Explicit transactions:</strong> use an execution strategy, or <code>DisableRetry = true</code>.</span>')
      });
      slides.push({...common,id:"sql-result",title:"THE RESULT",view:"result",html:'<figure class="app-screenshot"><img src="assets/screenshots/chapter-05-dashboard.png" alt="Actual Aspire dashboard showing sqlServer, its database resource, backendApi and frontend all Running. This checkpoint verifies SQL connectivity; application schema migrations follow in Chapter 07." decoding="sync"></figure>'});
    }
    if (chapter.id === "seeding") slides.push({...common,id:"seeding-result",title:"THE RESULT",view:"result",html:'<figure class="app-screenshot"><img src="assets/screenshots/chapter-07-dashboard.png" alt="Actual local Aspire dashboard with the Seeder actions menu open, showing the custom Reset and seed command mapped to the /seed endpoint. Seeder, backendApi, frontend, sqlServer and database are Running; migrations has Finished successfully." decoding="sync"></figure>'});
    if (chapter.id === "migrator") slides.push({...common,id:"migrator-result",title:"THE RESULT",view:"result",html:'<figure class="app-screenshot"><img src="assets/screenshots/chapter-06-dashboard.png" alt="Actual Aspire dashboard showing the one-shot migrations project Finished with exit code 0, while sqlServer, database, backendApi and frontend are Running after the schema gate succeeds." decoding="sync"></figure>'});
    if (chapter.id === "blobs") slides.push({...common,id:"blobs-result",title:"THE RESULT",view:"result",html:'<figure class="app-screenshot"><img src="assets/screenshots/chapter-08-dashboard.png" alt="Actual Aspire dashboard showing the running Azurite storage resource with its http://localhost:10000 blob endpoint and the tickets blob-container resource, alongside sqlServer, database, backendApi, frontend and seeder. migrations has finished with exit code 0." decoding="sync"></figure>'});
    if (chapter.id === "signalr") slides.push({...common,id:"signalr-result",title:"THE RESULT",view:"result",html:'<figure class="app-screenshot"><img src="assets/screenshots/chapter-11-dashboard.png" alt="Actual local Aspire dashboard showing the Serverless SignalR notifications emulator Running with backendApi, frontend, SQL, Blob storage and both ticket subscriptions and PDF worker fully in frame. migrations has Finished with verified exit code 0." decoding="sync"></figure>'});
    if (chapter.id === "servicebus") slides.push({...common,id:"servicebus-result",title:"THE RESULT",view:"result",html:'<figure class="app-screenshot"><img src="assets/screenshots/chapter-09-dashboard.png" alt="Actual local Aspire dashboard showing serviceBus, the ticket topic, ticket-generator and ticket-persistence subscriptions, and serviceBusProcessor all Running alongside the existing storage, SQL, API, frontend and Seeder resources. migrations has Finished with verified exit code 0." decoding="sync"></figure>'});
  });
  // Observability adds telemetry to the existing ticket pipeline, not a roadmap resource.
  const observabilityChapter = chapters.find(chapter => chapter.id === "observability");
  const observabilityNumber = String(observabilityChapter.number).padStart(2,"0");
  const observabilityCommon = {chapter:`Chapter ${observabilityNumber}`,chapterNumber:observabilityChapter.number,meta:`CHAPTER ${observabilityNumber} / OBSERVABILITY`,toc:false,outcome:""};
  const observabilitySlides = [
    {...observabilityCommon,id:"observability",title:"ARCHITECTURE CHANGE",topology:"messaging",addition:null,view:"architecture",claim:"Instrument the API + PDF worker; add telemetry, not another business resource.",html:p('<span class="claim">Instrument the API + PDF worker; add telemetry, not another business resource.</span>')+architecture("messaging","observability")},
    {...observabilityCommon,id:"observability-signals",title:"Three questions, three signals",view:"explanation",outcome:"Dependency telemetry explains the plumbing. Custom telemetry adds business meaning.",html:p('<span class="claim">Was it accepted, generated, or ready to download?</span>')+'<div class="fundamentals-visual">'+concepts([
      ['Logs','Describe events: what happened at a boundary.'],
      ['Traces','Explain individual work: request, generate, render and persist.'],
      ['Metrics','Summarize repeated outcomes and the duration of each attempt.']
    ])+'</div>'+p('HTTP acceptance is not ticket completion. SQL readiness arrives after the API handles the completion event. The Service Bus SDK carries trace context; Diagnostic-Id is not a business MessageId or CorrelationId. In this local run, both SDK consumers inherit a message-span parent and retain a link.')},
    codeSlide(observabilityCommon, {id:"observability-defaults",file:"WorkshopHub.AppHost.ServiceDefaults/Extensions.cs",context:"Keep existing HTTP, SQL, Blob and Service Bus instrumentation and exporters.",highlights:['AddMeter("WorkshopHub.Tickets")', '.AddSource("WorkshopHub.Tickets")'],text:`...
.WithMetrics(metrics =>
{
    metrics.AddMeter("WorkshopHub.Tickets")
        .AddAspNetCoreInstrumentation()
        ...;
})
.WithTracing(tracing =>
{
    tracing.AddSource(builder.Environment.ApplicationName)
        .AddSource("WorkshopHub.Tickets")
        ...;
})
...`,note:"ServiceDefaults stays independent of Application. Source and meter names must match."}),
    codeSlide(observabilityCommon, {id:"observability-broker",file:"WorkshopHub.Infrastructure.Messaging/DependencyInjection.cs",context:"Runtime exposed independent worker/API roots. Enable the installed SDK's ActivitySource before client construction in both hosts.",highlights:['AppContext.SetSwitch("Azure.Experimental.EnableActivitySource", true);'],text:`...
public static IHostApplicationBuilder AddWorkshopServiceBusClient(
    this IHostApplicationBuilder builder)
{
    AppContext.SetSwitch("Azure.Experimental.EnableActivitySource", true);
    builder.AddAzureServiceBusClient(ServiceBusTopology.ConnectionName, ...);
    ...
}
...`,note:"The smallest adapter correction: retain SDK producers/consumers and Diagnostic-Id propagation. No trace fields in contracts, duplicated spans or processor changes."}),
    codeSlide(observabilityCommon, {id:"observability-source",file:"WorkshopHub.Application/Observability/TicketTelemetry.cs",context:"One reusable source and one factory-managed meter. No OpenTelemetry package in Application.",highlights:['public static readonly ActivitySource Source = new("WorkshopHub.Tickets");', 'meterFactory.Create("WorkshopHub.Tickets")'],text:`...
public static readonly ActivitySource Source = new("WorkshopHub.Tickets");
...
public TicketTelemetry(IMeterFactory meterFactory)
{
    var meter = meterFactory.Create("WorkshopHub.Tickets");
    ...
}
...`,note:"Register TicketTelemetry with TryAddSingleton in API application/persistence composition and worker Program. The host provides IMeterFactory."}),
    codeSlide(observabilityCommon, {id:"observability-instruments",file:"WorkshopHub.Application/Observability/TicketTelemetry.cs",context:"Exactly two instruments, shared across the request / generate / persist stages.",highlights:['CreateCounter<long>("tickets.operations")', 'CreateHistogram<double>("tickets.operation.duration", "s")', '"ticket.stage"', '"ticket.outcome"', 'operations.Add(1, tags);', 'duration.Record(elapsed.TotalSeconds, tags);'],text:`...
operations = meter.CreateCounter<long>("tickets.operations");
duration = meter.CreateHistogram<double>("tickets.operation.duration", "s");
...
var tags = new TagList
{
    { "ticket.stage", stage }, { "ticket.outcome", outcome }
};
operations.Add(1, tags);
duration.Record(elapsed.TotalSeconds, tags);
...`,note:"Descriptions omitted. Record validates bounded stage/outcome pairs; metric tags contain no IDs, attendee details or error messages."}),
    codeSlide(observabilityCommon, {id:"observability-operation",file:"WorkshopHub.Application/Services/TicketRequestService.cs",context:"Internal span inherits the current HTTP / SDK activity. Finalize once, even on early return or exception.",highlights:['TicketTelemetry.Source.StartActivity("tickets.request", ActivityKind.Internal)', 'Stopwatch.GetTimestamp()', 'telemetry.Record("request", outcome, Stopwatch.GetElapsedTime(started));'],text:`...
using var activity = TicketTelemetry.Source.StartActivity("tickets.request", ActivityKind.Internal);
var started = Stopwatch.GetTimestamp();
...
try
{
    ...
}
finally
{
    telemetry.Record("request", outcome, Stopwatch.GetElapsedTime(started));
}
...`,note:"Generate and persist use the same boundary pattern. tickets.render records renderer detail before generation collapses it to transient; no extra renderer metric."}),
    {...observabilityCommon,id:"observability-metrics",title:"CUSTOM METRICS",view:"evidence",html:'<figure class="app-screenshot"><img src="assets/screenshots/chapter-10-metrics.png" alt="Actual local Aspire Dashboard custom ticket metrics showing tickets.operations processing attempts and tickets.operation.duration in seconds, split by bounded ticket.stage and ticket.outcome labels." decoding="sync"><figcaption><span class="capture-label">Actual local capture</span> Attempts by stage / outcome; duration in seconds per invocation, not total queue-to-readiness latency.</figcaption></figure>'},
    {...observabilityCommon,id:"observability-result",title:"THE RESULT",view:"result",html:'<figure class="app-screenshot"><img src="assets/screenshots/chapter-10-traces.png" alt="Actual local Aspire Dashboard ticket processing trace view with request, generate, render and persist business spans and both Service Bus consumers inheriting a message-span parent and retaining a link in this local run." decoding="sync"></figure>'}
  ];
  slides.splice(slides.findIndex(slide => slide.id === "signalr"), 0, ...observabilitySlides);
  slides.push({id:"agenda",title:"CHAPTERS",chapter:"Chapter menu",meta:"ASPIRE (.NET) WORKSHOP",html:`<ol class="agenda">${chapters.map(chapter=>`<li><a href="#chapter-${String(chapter.number).padStart(2,"0")}"><span class="number">${String(chapter.number).padStart(2,"0")}</span>${escape(chapter.title)}</a></li>`).join("")}</ol>`,outcome:""});
  // Actual local browser captures are preserved in chapter 02.
  const walkthrough = [
    {id:"current-catalog",title:"Find your next course",claim:"Start with search. Choose a course with a seat available.",alt:"Actual course catalog filtered to Creative thinking, practical tools, showing the search bar, availability checkbox, price and Book course action.",caption:"Search → available course → Book course. Availability reflects the saved demo booking.",outcome:"Public catalog · search by title or description · one seat per registration."},
    {id:"current-registration",title:"Register for the course",claim:"Review the course and introduce the participant.",alt:"Actual course registration page with course description, informational price and the participant form filled with Alex Demo and a fictitious example.test email.",caption:"Course summary and filled participant form, immediately before Reserve one seat.",outcome:"Participant name + email · demo contact details · no payment is collected."},
    {id:"current-receipt",title:"Your registration is saved",claim:"A saved receipt connects the participant to their booking.",alt:"Actual saved booking receipt for Alex Demo, reference E1A2CBF3, with Pending status and course availability decreased from nine to eight seats.",caption:"The same course now has one fewer available seat. Keep the saved booking reference.",outcome:"Pending reserves a seat · an administrator can confirm or cancel · no email is sent."},
    {id:"current-admin-courses",title:"Admin: manage the courses",claim:"Keep the catalog, pricing and capacity in one management space.",alt:"Actual admin course portal showing sidebar navigation, the selected published course, occupied seats and the filled editor for title, description, price and capacity.",caption:"Selected course and populated editor. No course changes were saved for this capture.",outcome:"Create / edit / archive courses · existing receipts preserve their booked title and price."},
    {id:"current-admin-bookings",title:"Admin: manage registrations",claim:"Find the same reference and review the participant’s place.",alt:"Actual admin bookings portal filtered to reference E1A2CBF3, showing Alex Demo, Pending status and Confirm place and Cancel booking controls.",caption:"The receipt’s reference appears in the linked admin history. Its status is still Pending.",outcome:"Filter by course, participant, reference or status · confirm or cancel from the admin portal."}
  ].map(slide => ({
    ...slide,chapter:"Chapter 02",chapterNumber:2,meta:"CHAPTER 02 / CURRENT APPLICATION",view:"screenshot",toc:false,
    html:p(`<span class="claim">${escape(slide.claim)}</span>`)+`<figure class="app-screenshot"><img src="assets/screenshots/${slide.id}.png" alt="${escape(slide.alt)}" decoding="sync"><figcaption><span class="capture-label">Actual local capture</span> ${escape(slide.caption)}</figcaption></figure>`
  }));
  slides.splice(slides.findIndex(slide => slide.id==="blazor-start"),0,...walkthrough);
  // Setup prepares the workstation and the embedded database before ASPIRE orchestrates anything.
  const setupChapter = chapters.find(chapter => chapter.id === "setup");
  const setupNumber = String(setupChapter.number).padStart(2,"0");
  const setupCommon = {chapter:`Chapter ${setupNumber}`,chapterNumber:setupChapter.number,meta:`CHAPTER ${setupNumber} / SETUP THE PROJECT`,toc:false,outcome:""};
  // The command is one line of plain text: the copy action hands the participant the exact shell value, highlight included.
  const migrationCommand = 'dotnet ef database update --project WorkshopHub.Infrastructure --startup-project WorkshopHub.Infrastructure --context SqliteBookingsDbContext --connection "Data Source=<mark class="code-highlight">&lt;full path&gt;</mark>\\WorkshopHub.Api\\App_Data\\workshophub.db"';
  slides.splice(slides.findIndex(slide => slide.id==="apphost"),0,
    {...setupCommon,id:"setup",title:"PREREQUISITES",view:"explanation",outcome:"Both are workstation prerequisites; neither adds anything to the repository.",html:
      p('<span class="claim">Prepare the machine before ASPIRE starts its first container.</span>')+
      '<div class="fundamentals-visual">'+concepts([
        ['Podman, rootless','A dedicated machine named <code>podman-machine-default</code> runs in rootless mode and hosts the SQL Server, Azurite, Service Bus and SignalR emulators.'],
        ['WSL updated','<code>wsl --update</code> refreshes the WSL kernel the Podman machine boots. Outdated kernels break emulator networking.'],
        ['Verified, not assumed','<code>podman machine list</code> shows the machine and its state; <code>podman info --format "{{.Host.Security.Rootless}}"</code> returns <code>true</code>.']
      ])+'</div>'+
      p('Both are per workstation, never per repository. Let ASPIRE select the runtime for the current shell with <code>$env:ASPIRE_CONTAINER_RUNTIME = \'podman\'</code>, and run one emulator stack at a time.')},
    {...setupCommon,id:"setup-migrations",title:"THE CODE",view:"code",outcome:"Replace the placeholder with your absolute checkout path before running.",file:"dotnet ef · apply the SQLite migrations",html:
      '<h2 class="code-file">dotnet ef · apply the SQLite migrations</h2>'+
      '<p class="code-context">Run from the repository root. Replace <code>&lt;full path&gt;</code> with the absolute path of your checkout, without a trailing separator.</p>'+
      '<div class="prompt-panel"><div class="prompt-actions"><span class="prompt-label">Command · copy and run</span><button type="button" class="prompt-copy" data-prompt-copy>Copy command</button></div>'+
      `<pre class="prompt-text"><code>${migrationCommand}</code></pre></div>`+
      '<p class="code-note">The API opens <code>WorkshopHub.Api/App_Data/workshophub.db</code> through its SQLite context, so the connection string must point at that file. <code>database update</code> applies the pending SQLite migrations and creates the file when it does not exist yet.</p>'}
  );
  // Integration tests reuse the real AppHost; the fixture makes its resources disposable.
  const testingChapter = chapters.find(chapter => chapter.id === "testing");
  const testingNumber = String(testingChapter.number).padStart(2,"0");
  const testingCommon = {chapter:`Chapter ${testingNumber}`,chapterNumber:testingChapter.number,meta:`CHAPTER ${testingNumber} / TESTING`,toc:false,outcome:""};
  slides.push(
    {...testingCommon,id:"testing",title:"Test the distributed application",view:"explanation",outcome:"One xUnit test drives the real API and worker through the existing AppHost.",html:
      p('<span class="claim">Confirm a booking. Wait for its ticket. Download a real PDF.</span>')+
      '<div class="fundamentals-visual">'+concepts([
        ['xUnit owns the run','A shared async fixture starts AppHost, exposes an HTTP client and disposes the application.'],
        ['Aspire owns the setup','Reuse project references, dependency wiring, migrations and readiness gates.'],
        ['Podman runs infrastructure','Real local SQL Server, Azurite, Service Bus and SignalR emulators. No cloud deployment.']
      ])+'</div>'+p('This is an integration test, not a mocked unit test or a browser test. API and worker run as .NET processes; infrastructure runs in containers. SignalR is present, but live browser notifications are not asserted.')},
    codeSlide(testingCommon, {id:"testing-project",file:"Directory.Packages.props",context:"Pin test dependencies centrally; match the AppHost's Aspire version.",columns:true,highlights:['Aspire.Hosting.Testing','13.6.5','xunit'],text:`...
<PackageVersion Include="Aspire.Hosting.Testing"
                Version="13.6.5" />
<PackageVersion Include="Microsoft.NET.Test.Sdk"
                Version="17.14.1" />
<PackageVersion Include="xunit" Version="2.9.3" />
<PackageVersion Include="xunit.runner.visualstudio"
                Version="3.1.4" />
...`,additionalExamples:[{file:"WorkshopHub.IntegrationTests/WorkshopHub.IntegrationTests.csproj",context:"Reference AppHost for the generated Projects type, and Contracts for typed HTTP payloads.",highlights:['<IsTestProject>true</IsTestProject>','Aspire.Hosting.Testing','WorkshopHub.AppHost','WorkshopHub.Contracts'],text:`...
<IsTestProject>true</IsTestProject>
...
<PackageReference Include="Aspire.Hosting.Testing" />
<PackageReference Include="Microsoft.NET.Test.Sdk" />
<PackageReference Include="xunit" />
<PackageReference Include="xunit.runner.visualstudio">
  <PrivateAssets>all</PrivateAssets>
  ...
</PackageReference>
...
<ProjectReference
  Include="../WorkshopHub.AppHost/WorkshopHub.AppHost.csproj" />
<ProjectReference
  Include="../WorkshopHub.Contracts/WorkshopHub.Contracts.csproj" />
...`}],note:"Use the existing .NET 10 solution settings. Add the test project to WorkshopHub.sln; these dependencies belong in the test project, not the API."}),
    codeSlide(testingCommon, {id:"testing-startup",file:"WorkshopHub.IntegrationTests/MessagingAppFixture.cs",context:"InitializeAsync runs once for the collection. Bound startup to three minutes.",highlights:['DistributedApplicationTestingBuilder.CreateAsync<Projects.WorkshopHub_AppHost>','IsolateResources(_builder);','WaitForResourceHealthyAsync','CreateHttpClient("backendApi", "http")'],text:`...
using var startup = new CancellationTokenSource(TimeSpan.FromMinutes(3));
_builder = await DistributedApplicationTestingBuilder.CreateAsync<Projects.WorkshopHub_AppHost>(startup.Token);
IsolateResources(_builder);
...
_app = await _builder.BuildAsync(startup.Token);
await _app.StartAsync(startup.Token);
await Task.WhenAll(
    _app.ResourceNotifications.WaitForResourceHealthyAsync("backendApi", startup.Token),
    _app.ResourceNotifications.WaitForResourceHealthyAsync("serviceBusProcessor", startup.Token));
_api = _app.CreateHttpClient("backendApi", "http");
_api.Timeout = TimeSpan.FromSeconds(30);
...`,note:"Wait for health, not a guessed startup delay. AppHost already gates API startup on successful migrations. CreateHttpClient resolves the allocated endpoint; no hard-coded localhost port."}),
    {...testingCommon,id:"testing-isolation",title:"Keep tests away from developer data",view:"explanation",outcome:"Isolation is a fixture policy; reusing AppHost alone does not provide it.",html:
      p('<span class="claim">The development model is persistent. Each test run must be disposable.</span>')+
      '<div class="fundamentals-visual">'+concepts([
        ['Fresh storage','Remove named volume mounts so application SQL and emulator data start fresh. Never delete developer volumes.'],
        ['Allocated endpoints','Remove fixed container names and clear proxied host ports, including Azurite’s development port 10000.'],
        ['Session lifetime','Override persistent lifetimes on native containers and Azure emulator wrappers. Dispose AppHost after the collection.']
      ])+'</div>'+p('Inspect every resource: Azure emulator annotations can live on logical resources. The fixture sets project environments to Development and asserts that configured volume mounts, fixed proxied ports and persistent lifetimes are absent. Images can still create anonymous volumes; no development data volume is reused.')},
    codeSlide(testingCommon, {id:"testing-isolation-code",file:"WorkshopHub.IntegrationTests/MessagingAppFixture.cs",context:"Inside IsolateResources: mutate the test builder before BuildAsync. The original AppHost stays unchanged.",highlights:['builder.Resources','resource.Annotations.Remove(mount);','resource.Annotations.Remove(name);','endpoint.Port = null;','WithLifetime(ContainerLifetime.Session)'],text:`...
foreach (var resource in builder.Resources)
{
    foreach (var mount in resource.Annotations.OfType<ContainerMountAnnotation>()
                 .Where(mount => mount.Type == ContainerMountType.Volume).ToArray())
        resource.Annotations.Remove(mount);
    foreach (var name in resource.Annotations.OfType<ContainerNameAnnotation>().ToArray())
        resource.Annotations.Remove(name);
    foreach (var endpoint in resource.Annotations.OfType<EndpointAnnotation>().Where(endpoint => endpoint.IsProxied))
        endpoint.Port = null;
    ...
    if (container is not null)
        builder.CreateResourceBuilder(container).WithLifetime(ContainerLifetime.Session);
    ...
}
...`,note:"Excerpt omits braces and wrapper selection for readability. The actual switch handles ContainerResource, AzureStorageEmulatorResource, AzureServiceBusEmulatorResource and AzureSignalREmulatorResource."}),
    {...testingCommon,id:"testing-lifecycle",title:"Share setup. Diagnose failures. Clean up.",view:"explanation",outcome:"The fixture owns the environment from startup through teardown, including startup failures.",html:
      p('<span class="claim">Reliable integration tests need a lifecycle, not only assertions.</span>')+
      '<div class="fundamentals-visual">'+concepts([
        ['One collection fixture','ICollectionFixture + IAsyncLifetime share one AppHost. DisableParallelization avoids competing full-stack runs.'],
        ['Useful failure output','Report the current phase, elapsed time, resource state and recent logs. Bound diagnostics to five seconds and omit credential-related lines.'],
        ['Always dispose','Dispose the HTTP client, application and builder. The fixture also tears down partial startup before rethrowing the failure.']
      ])+'</div>'+p('Unique course and booking data avoid collisions within the shared collection. Each application launch has fresh infrastructure; each test does not automatically get a separate database.')},
    {...testingCommon,id:"testing-podman",title:"PODMAN DURING THE TEST RUN",view:"evidence",html:'<figure class="app-screenshot"><img src="assets/screenshots/chapter-12-testing-podman.png" alt="Actual Podman Desktop Containers view during integration-test startup, showing five running containers: application SQL Server, the separate Service Bus SQL backend, Service Bus, Azurite storage and SignalR notifications." decoding="sync"><figcaption><span class="capture-label">Actual local capture</span> Five containers RUNNING during fixture startup, including Service Bus’s own SQL backend. This view does not prove their health or test success. The subsequent integration test passed (1/1); fixture teardown removed all five containers.</figcaption></figure>'}
  );
  const resourceGroups = [
    ["ASPIRE foundations",[
      sources.overview,sources.apphost,sources.discovery,sources.health,sources.defaults,sources.integrations,sources.dashboard,
      ["ASPIRE 13.6 release","https://aspire.dev/whats-new/aspire-13-6/"],
      ["Prerequisites","https://aspire.dev/get-started/prerequisites/"],
      ["Install the ASPIRE CLI","https://aspire.dev/get-started/install-cli/"],
      ["AppHost project template · 13.6.4","https://github.com/microsoft/aspire/blob/v13.6.4/src/Aspire.ProjectTemplates/templates/aspire-apphost/Aspire.AppHost1.csproj"],
      ["ServiceDefaults source · 13.6.4","https://github.com/microsoft/aspire/blob/v13.6.4/src/Aspire.ProjectTemplates/templates/aspire-servicedefaults/Extensions.cs"],
      ["HTTP resilience · unsafe retry policy","https://learn.microsoft.com/en-us/dotnet/core/resilience/http-resilience"]
    ]],
    ["Resource integrations",[
      ["SQL Server hosting · 13.6.5","https://github.com/microsoft/aspire/blob/v13.6.5/src/Aspire.Hosting.SqlServer/README.md"],
      ["Enrich an existing SQL Server DbContext · 13.6.5","https://github.com/microsoft/aspire/blob/v13.6.5/src/Components/Aspire.Microsoft.EntityFrameworkCore.SqlServer/README.md"],
      sources.blobHosting,sources.blobClient,sources.busHosting,sources.busApi,sources.busClient,sources.busStart,
      ["Azurite emulator · install and ports","https://learn.microsoft.com/en-us/azure/storage/common/storage-use-azurite"],
      ["Azure Storage Explorer","https://learn.microsoft.com/en-us/azure/storage/blobs/storage-quickstart-blobs-storage-explorer"],
      ["Playwright · PDF generation","https://playwright.dev/dotnet/docs/api/class-page#page-pdf"],
      ["SignalR hosting","https://aspire.dev/integrations/cloud/azure/azure-signalr/azure-signalr-host/"],
      ["SignalR source · 13.6.5","https://github.com/microsoft/aspire/tree/v13.6.5/src/Aspire.Hosting.Azure.SignalR"],
      ["SignalR Management SDK","https://learn.microsoft.com/azure/azure-signalr/signalr-howto-use-management-sdk"]
    ]],
    ["Observability",[
      [".NET · distributed tracing instrumentation","https://learn.microsoft.com/en-us/dotnet/core/diagnostics/distributed-tracing-instrumentation-walkthroughs"],
      [".NET · custom metrics","https://learn.microsoft.com/en-us/dotnet/core/diagnostics/metrics-instrumentation"],
      ["Aspire · telemetry","https://aspire.dev/fundamentals/telemetry/"],
      ["Dashboard · traces","https://aspire.dev/dashboard/explore/"],
      ["Service Bus · distributed tracing","https://learn.microsoft.com/en-us/azure/service-bus-messaging/service-bus-end-to-end-tracing"],
      ["Service Bus .NET SDK · ActivitySource switch","https://learn.microsoft.com/en-us/dotnet/api/overview/azure/messaging.servicebus-readme?view=azure-dotnet#distributed-tracing"]
    ]],
    ["Testing",[
      ["Aspire · testing overview","https://aspire.dev/testing/overview/"],
      ["Aspire testing source · 13.6.5","https://github.com/microsoft/aspire/tree/v13.6.5/src/Aspire.Hosting.Testing"],
      ["dotnet test · filters and logging","https://learn.microsoft.com/en-us/dotnet/core/tools/dotnet-test"],
      ["xUnit · shared fixtures","https://xunit.net/docs/shared-context"],
      ["Playwright .NET · browser installation","https://playwright.dev/dotnet/docs/browsers"],
      ["Podman · container list","https://docs.podman.io/en/latest/markdown/podman-ps.1.html"]
    ]],
    ["Lifecycle and local tools",[
      ["WaitForCompletion · 13.6.5","https://github.com/microsoft/aspire/blob/v13.6.5/src/Aspire.Hosting/ResourceBuilderExtensions.cs"],
      ["EF Core migration application","https://learn.microsoft.com/en-us/ef/core/managing-schemas/migrations/applying"],
      ["EF Core connection resiliency","https://learn.microsoft.com/en-us/ef/core/miscellaneous/connection-resiliency"],
      ["Executable lifecycle · 13.6.5","https://github.com/microsoft/aspire/tree/v13.6.5/src/Aspire.Hosting/Dcp"],
      ["Resource commands · 13.6.5","https://github.com/microsoft/aspire/blob/v13.6.5/src/Aspire.Hosting/ResourceBuilderExtensions.cs"]
    ]],
    ["Visual references and attribution",[
      ["Microsoft Azure icons · usage terms","https://learn.microsoft.com/en-us/azure/architecture/icons/"],
      ["Official Azure icon pack · V25","https://arch-center.azureedge.net/icons/Azure_Public_Service_Icons_V25.zip"],
      ["Bundled icon provenance","assets/azure/PROVENANCE.txt"],
      ["Montserrat · bundled font license","assets/Montserrat-OFL.txt"]
    ]]
  ];
  const seenResources = new Set();
  const resourceCatalogue = `<div class="resource-catalogue">${resourceGroups.map(([title,entries])=>`<section class="resource-group"><h2>${escape(title)}</h2><ul>${entries.filter(([,href])=>{if(seenResources.has(href))return false;seenResources.add(href);return true;}).map(([label,href])=>`<li><a href="${escape(href)}" target="_blank" rel="noopener noreferrer">${escape(label)}</a></li>`).join("")}</ul></section>`).join("")}</div>`;
  const referencesChapter = chapters.find(chapter => chapter.id === "finish");
  const referencesNumber = String(referencesChapter.number).padStart(2,"0");
  slides.push({id:"finish",title:referencesChapter.title,chapter:`Chapter ${referencesNumber}`,chapterNumber:referencesChapter.number,view:"resources",toc:false,meta:`CHAPTER ${referencesNumber} / REFERENCES`,html:resourceCatalogue,outcome:""});
  // All content openers exist before inserting the metadata-driven chapter dividers.
  chapters.forEach(chapter => {
    const number = String(chapter.number).padStart(2,"0");
    const opener = slides.findIndex(slide => slide.id===chapter.id);
    if(opener<0)throw new Error(`Missing chapter opener: ${chapter.id}`);
    slides.splice(opener,0,{id:`chapter-${number}`,title:chapter.title,chapter:`Chapter ${number}`,chapterNumber:chapter.number,meta:`CHAPTER ${number}`,view:"divider",toc:true,outcome:"",html:""});
  });
  slides.unshift({id:"workshop-cover",title:"ASPIRE (.NET)",chapter:"",meta:"2026 / Gregory Nickmans",view:"divider",toc:false,html:"",outcome:""});
  const chapterOverview = slides.splice(slides.findIndex(slide => slide.id==="agenda"),1)[0];
  slides.splice(1,0,chapterOverview);
  window.workshopTopologies = topologies;
  window.workshopChapters = chapters;
  window.workshopSlides = slides;
  window.workshopHashAliases = {
    "why-aspire-preview":"aspire-why","why-aspire-steps":"aspire-model","blazor-start-preview":"build-notifications","blazor-start-steps":"blazor-start",
    cover:"why-aspire",ready:"blazor-start","why-monolith":"why-aspire","monolith-calls":"blazor-start","synthetic-data":"build-notifications","blazor-lab":"blazor-start",
    "reference-wait":"apphost","first-observation":"apphost","service-defaults":"apphost-api","apphost-lab":"apphost-code","apphost-preview":"apphost","apphost-steps":"apphost-code",
    "sql-resource":"sql","sql-lab":"sql-code","sql-preview":"sql","sql-steps":"sql-code","migration-gate":"migrator","migration-failure":"migrator-lifetime",
    "seeding-preview":"seeding","seeding-steps":"seeding-code","seeding-command-auth":"seeding-commands","seeding-request-auth":"seeding-persistence","blob-wire":"blobs","blob-lab":"blobs-code","blobs-preview":"blobs","blobs-steps":"blobs-code",
    "blob-port":"blobs-port","blob-prompt":"blobs-prompt","blob-explorer":"blobs-explorer","blob-result":"blobs-result",
    "queue-wire":"servicebus","queue-idempotency":"servicebus-code","consistency-gap":"servicebus-code","queue-lab":"servicebus-code","servicebus-preview":"servicebus","servicebus-steps":"servicebus-code",
    "signalr-modes":"signalr","notification-plumbing":"signalr-code","signalr-diagnostics":"signalr-code","signalr-lab":"signalr-code","signalr-preview":"signalr","signalr-steps":"signalr-code"
  };
})();
